if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si416:{
name:'Simulation_1',
type:1268,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si416c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si408',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si416c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:416,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si416',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si408:{
name:'Simulation_non_responsive_1',
type:1268,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si408c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si416',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si427',
t:1269
}
,{
n:'si447',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si416',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si408c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:408,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si408',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:424,
tsp:50,
ip:'dr/0424.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si427:{
name:'Click_box_1',
type:1269,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si427c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":12,"left":186,"width":941,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(500);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:28.787,
lcapid:'si447',
si:[{
n:'si437',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[427]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si427c:{
b:[186,12,1127,62],
fh:false,
fw:false,
uid:427,
iso:false,
css:{
360:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si427',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[186,12,1127,62],
vb:[186,12,1127,62]
},
si437:{
name:'Shape_1',
type:612,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si437c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[437]
}
]
,
stis:0,
bstiid:427,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si427',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si437c:{
b:[0,0,941,50],
fh:false,
fw:false,
uid:437,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si437',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,943,52],
vb:[-2,-2,943,52]
},
si447:{
name:'Rectangle_1',
type:612,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si447c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:458,
stt:0,
dsr:'Default_State',
stsi:[447]
}
,{
stn:470,
stt:102,
dsr:'Failure',
stsi:[471]
}
,{
stn:481,
stt:103,
dsr:'Hint',
stsi:[482]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si447','si460','si471','si482'],
isDD:false
},
si447c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:447,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si447',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si460:{
name:'',
type:612,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si460c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[460]
}
]
,
stis:0,
bstiid:447,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si460c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:460,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si460',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si471:{
name:'',
type:612,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si471c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[471]
}
]
,
stis:0,
bstiid:447,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si471c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:471,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si471',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si482:{
name:'',
type:612,
from:1,
to:864,
rp:0,
rpa:0,
mdi:'si482c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:28.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si408',
retainState:false,
immo:false,
apsn:'Slide390',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si447',
stl:[{
stn:'Normal',
stt:0,
stsi:[482]
}
]
,
stis:0,
bstiid:447,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:447,
isDD:false
},
si482c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:482,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si482',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide390:{
lb:'Simulation slide 1',
id:390,
from:1,
to:864,
iols:0,
i360qs:false,
sdu:28.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide390c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si416',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
500:{
ts:''
}

}

},
Slide390c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:390,
dn:'Slide390',
visible:'1'
},
si533:{
name:'Simulation_2',
type:1268,
from:865,
to:864,
rp:0,
rpa:0,
mdi:'si533c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si525',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si533c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:533,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si533',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si525:{
name:'Simulation_non_responsive_2',
type:1268,
from:865,
to:864,
rp:0,
rpa:0,
mdi:'si525c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si533',
retainState:false,
immo:false,
apsn:'Slide507',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si533',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si525c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:525,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si525',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:541,
tsp:50,
ip:'dr/0541.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide507:{
lb:'Simulation slide 2',
id:507,
from:865,
to:952,
iols:0,
i360qs:false,
sdu:2.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide507c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si533',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide507c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:507,
dn:'Slide507',
visible:'1'
},
si570:{
name:'Simulation_3',
type:1268,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si570c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si562',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si570c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:570,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si570',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si562:{
name:'Simulation_non_responsive_3',
type:1268,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si562c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si570',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si581',
t:1269
}
,{
n:'si601',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si570',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si562c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:562,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si562',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:578,
tsp:50,
ip:'dr/0578.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si581:{
name:'Click_box_2',
type:1269,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si581c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":534,"left":152,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si562',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(654);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:6.28,
lcapid:'si601',
si:[{
n:'si591',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[581]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si581c:{
b:[152,534,186,554],
fh:false,
fw:false,
uid:581,
iso:false,
css:{
360:{
l:'15.638%',
t:'87.829%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'15.638%',
lhID:-1,
lvEID:0,
lvV:'87.829%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'15.638%',
t:'87.829%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'15.638%',
lhID:-1,
lvEID:0,
lvV:'87.829%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'15.638%',
t:'87.829%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'15.638%',
lhID:-1,
lvEID:0,
lvV:'87.829%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si581',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[152,534,186,554],
vb:[152,534,186,554]
},
si591:{
name:'Shape_2',
type:612,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si591c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[591]
}
]
,
stis:0,
bstiid:581,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si581',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si591c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:591,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si591',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si601:{
name:'Rectangle_2',
type:612,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si601c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":594,"left":167,"width":300,"height":"auto"}}',
parentGroup:'si562',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:612,
stt:0,
dsr:'Default_State',
stsi:[601]
}
,{
stn:624,
stt:102,
dsr:'Failure',
stsi:[625]
}
,{
stn:635,
stt:103,
dsr:'Hint',
stsi:[636]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si601','si614','si625','si636'],
isDD:false
},
si601c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:601,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si601',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si614:{
name:'',
type:612,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si614c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":594,"left":167,"width":300,"height":"auto"}}',
parentGroup:'si562',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si601',
stl:[{
stn:'Normal',
stt:0,
stsi:[614]
}
]
,
stis:0,
bstiid:601,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:601,
isDD:false
},
si614c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:614,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si614',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si625:{
name:'',
type:612,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si625c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":594,"left":167,"width":300,"height":"auto"}}',
parentGroup:'si562',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si601',
stl:[{
stn:'Normal',
stt:0,
stsi:[625]
}
]
,
stis:0,
bstiid:601,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:601,
isDD:false
},
si625c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:625,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si625',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si636:{
name:'',
type:612,
from:953,
to:1141,
rp:0,
rpa:0,
mdi:'si636c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":594,"left":167,"width":300,"height":"auto"}}',
parentGroup:'si562',
retainState:false,
immo:false,
apsn:'Slide544',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si601',
stl:[{
stn:'Normal',
stt:0,
stsi:[636]
}
]
,
stis:0,
bstiid:601,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:601,
isDD:false
},
si636c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:636,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si636',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide544:{
lb:'Simulation slide 3',
id:544,
from:953,
to:1141,
iols:0,
i360qs:false,
sdu:6.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide544c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si570',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
654:{
ts:''
}

}

},
Slide544c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:544,
dn:'Slide544',
visible:'1'
},
si687:{
name:'Simulation_4',
type:1268,
from:1142,
to:1141,
rp:0,
rpa:0,
mdi:'si687c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide661',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si679',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si687c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:687,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si687',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si679:{
name:'Simulation_non_responsive_4',
type:1268,
from:1142,
to:1141,
rp:0,
rpa:0,
mdi:'si679c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si687',
retainState:false,
immo:false,
apsn:'Slide661',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si687',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si679c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:679,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si679',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:695,
tsp:50,
ip:'dr/0695.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide661:{
lb:'Simulation slide 4',
id:661,
from:1142,
to:1220,
iols:0,
i360qs:false,
sdu:2.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide661c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si687',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide661c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:661,
dn:'Slide661',
visible:'1'
},
si724:{
name:'Simulation_5',
type:1268,
from:1221,
to:1220,
rp:0,
rpa:0,
mdi:'si724c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide698',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si716',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si724c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:724,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si724',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si716:{
name:'Simulation_non_responsive_5',
type:1268,
from:1221,
to:1220,
rp:0,
rpa:0,
mdi:'si716c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si724',
retainState:false,
immo:false,
apsn:'Slide698',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si724',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si716c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:716,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si716',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:732,
tsp:50,
ip:'dr/0732.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide698:{
lb:'Simulation slide 5',
id:698,
from:1221,
to:1229,
iols:0,
i360qs:false,
sdu:0.3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide698c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si724',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide698c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:698,
dn:'Slide698',
visible:'1'
},
si753:{
name:'Video_1',
type:1268,
from:1230,
to:1250,
rp:0,
rpa:0,
mdi:'si753c',
tag:'container-fmr-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
retainState:false,
immo:false,
apsn:'Slide735',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si772',
t:365
}
]
,
containerType:'fmr-video-widget',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si753c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:753,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si753',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si772:{
name:'SlideVideo_1',
type:365,
from:1230,
to:1250,
rp:0,
rpa:0,
mdi:'si772c',
tag:'video',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0.7,
presetData:[{
presetId:'',
presetType:-1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si753',
retainState:false,
immo:false,
apsn:'Slide735',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vestr:0,
vim:0,
trin:0,
trout:0,
isDD:false
},
si772c:{
b:[-234,-236,1206,844],
fh:false,
fw:false,
uid:772,
iso:false,
css:{
360:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-24.074%',
t:'-38.816%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-24.074%',
lhID:-1,
lvEID:0,
lvV:'-38.816%',
lvID:-1,
w:'148.148%',
h:'177.632%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si772',
visible:1,
effectiveVi:1,
JSONEffectData:false,
videoThumbnailSrc:'dr/0768.png',
mp4:'vr/Vi761.mp4',
vsf:0,
vst:0.7,
o:100,
vbwr:[-235,-237,1207,845],
vb:[-235,-237,1207,845]
},
Slide735:{
lb:'Simulation slide 6',
id:735,
from:1230,
to:1250,
iols:0,
i360qs:false,
sdu:0.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide735c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si753',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide735c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:735,
dn:'Slide735',
visible:'1'
},
si805:{
name:'Simulation_6',
type:1268,
from:1251,
to:1250,
rp:0,
rpa:0,
mdi:'si805c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide779',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si797',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si805c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:805,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si805',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si797:{
name:'Simulation_non_responsive_6',
type:1268,
from:1251,
to:1250,
rp:0,
rpa:0,
mdi:'si797c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si805',
retainState:false,
immo:false,
apsn:'Slide779',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si805',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si797c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:797,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si797',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:732,
tsp:50,
ip:'dr/0732.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide779:{
lb:'Simulation slide 7',
id:779,
from:1251,
to:1453,
iols:0,
i360qs:false,
sdu:6.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide779c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si805',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide779c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:779,
dn:'Slide779',
visible:'1'
},
si839:{
name:'Simulation_7',
type:1268,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si839c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si831',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si839c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:839,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si839',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si831:{
name:'Simulation_non_responsive_7',
type:1268,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si831c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si839',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si847',
t:1269
}
,{
n:'si867',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si839',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si831c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:831,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si831',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:732,
tsp:50,
ip:'dr/0732.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si847:{
name:'Click_box_3',
type:1269,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si847c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":12,"left":186,"width":941,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si831',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(920);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.753,
lcapid:'si867',
si:[{
n:'si857',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[847]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si847c:{
b:[186,12,1127,62],
fh:false,
fw:false,
uid:847,
iso:false,
css:{
360:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si847',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[186,12,1127,62],
vb:[186,12,1127,62]
},
si857:{
name:'Shape_3',
type:612,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si857c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[857]
}
]
,
stis:0,
bstiid:847,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si847',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si857c:{
b:[0,0,941,50],
fh:false,
fw:false,
uid:857,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si857',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,943,52],
vb:[-2,-2,943,52]
},
si867:{
name:'Rectangle_3',
type:612,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si867c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si831',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:878,
stt:0,
dsr:'Default_State',
stsi:[867]
}
,{
stn:890,
stt:102,
dsr:'Failure',
stsi:[891]
}
,{
stn:901,
stt:103,
dsr:'Hint',
stsi:[902]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si867','si880','si891','si902'],
isDD:false
},
si867c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:867,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si867',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si880:{
name:'',
type:612,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si880c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si831',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si867',
stl:[{
stn:'Normal',
stt:0,
stsi:[880]
}
]
,
stis:0,
bstiid:867,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:867,
isDD:false
},
si880c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:880,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si880',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si891:{
name:'',
type:612,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si891c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si831',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si867',
stl:[{
stn:'Normal',
stt:0,
stsi:[891]
}
]
,
stis:0,
bstiid:867,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:867,
isDD:false
},
si891c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:891,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si891',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si902:{
name:'',
type:612,
from:1454,
to:1776,
rp:0,
rpa:0,
mdi:'si902c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.8,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si831',
retainState:false,
immo:false,
apsn:'Slide813',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si867',
stl:[{
stn:'Normal',
stt:0,
stsi:[902]
}
]
,
stis:0,
bstiid:867,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:867,
isDD:false
},
si902c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:902,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si902',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide813:{
lb:'Simulation slide 8',
id:813,
from:1454,
to:1776,
iols:0,
i360qs:false,
sdu:10.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide813c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si839',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
920:{
ts:''
}

}

},
Slide813c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:813,
dn:'Slide813',
visible:'1'
},
si953:{
name:'Simulation_8',
type:1268,
from:1777,
to:1776,
rp:0,
rpa:0,
mdi:'si953c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide927',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si945',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si953c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:953,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si953',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si945:{
name:'Simulation_non_responsive_8',
type:1268,
from:1777,
to:1776,
rp:0,
rpa:0,
mdi:'si945c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si953',
retainState:false,
immo:false,
apsn:'Slide927',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si953',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si945c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:945,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si945',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:961,
tsp:50,
ip:'dr/0961.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide927:{
lb:'Simulation slide 9',
id:927,
from:1777,
to:1800,
iols:0,
i360qs:false,
sdu:0.8,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide927c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si953',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide927c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:927,
dn:'Slide927',
visible:'1'
},
si990:{
name:'Simulation_9',
type:1268,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si990c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si982',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si990c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:990,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si990',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si982:{
name:'Simulation_non_responsive_9',
type:1268,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si982c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si990',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1001',
t:1269
}
,{
n:'si1021',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si990',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si982c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:982,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si982',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:998,
tsp:50,
ip:'dr/0998.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1001:{
name:'Click_box_4',
type:1269,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1001c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":502,"left":1235,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si982',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1074);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.007,
lcapid:'si1021',
si:[{
n:'si1011',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1001]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1001c:{
b:[1235,502,1269,522],
fh:false,
fw:false,
uid:1001,
iso:false,
css:{
360:{
l:'127.058%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'127.058%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'127.058%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'127.058%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'127.058%',
t:'82.566%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'127.058%',
lhID:-1,
lvEID:0,
lvV:'82.566%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1001',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1235,502,1269,522],
vb:[1235,502,1269,522]
},
si1011:{
name:'Shape_4',
type:612,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1011c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1011]
}
]
,
stis:0,
bstiid:1001,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1001',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1011c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1011,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1011',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1021:{
name:'Rectangle_4',
type:612,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1021c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":920,"width":300,"height":"auto"}}',
parentGroup:'si982',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1032,
stt:0,
dsr:'Default_State',
stsi:[1021]
}
,{
stn:1044,
stt:102,
dsr:'Failure',
stsi:[1045]
}
,{
stn:1055,
stt:103,
dsr:'Hint',
stsi:[1056]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1021','si1034','si1045','si1056'],
isDD:false
},
si1021c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1021,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1021',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1034:{
name:'',
type:612,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1034c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":920,"width":300,"height":"auto"}}',
parentGroup:'si982',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1021',
stl:[{
stn:'Normal',
stt:0,
stsi:[1034]
}
]
,
stis:0,
bstiid:1021,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1021,
isDD:false
},
si1034c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1034,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1034',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1045:{
name:'',
type:612,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1045c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":920,"width":300,"height":"auto"}}',
parentGroup:'si982',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1021',
stl:[{
stn:'Normal',
stt:0,
stsi:[1045]
}
]
,
stis:0,
bstiid:1021,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1021,
isDD:false
},
si1045c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1045,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1045',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1056:{
name:'',
type:612,
from:1801,
to:2101,
rp:0,
rpa:0,
mdi:'si1056c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":562,"left":920,"width":300,"height":"auto"}}',
parentGroup:'si982',
retainState:false,
immo:false,
apsn:'Slide964',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1021',
stl:[{
stn:'Normal',
stt:0,
stsi:[1056]
}
]
,
stis:0,
bstiid:1021,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1021,
isDD:false
},
si1056c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1056,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1056',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide964:{
lb:'Simulation slide 10',
id:964,
from:1801,
to:2101,
iols:0,
i360qs:false,
sdu:10,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide964c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si990',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1074:{
ts:''
}

}

},
Slide964c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:964,
dn:'Slide964',
visible:'1'
},
si1107:{
name:'Simulation_10',
type:1268,
from:2102,
to:2101,
rp:0,
rpa:0,
mdi:'si1107c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1081',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1099',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1107c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1107,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1107',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1099:{
name:'Simulation_non_responsive_10',
type:1268,
from:2102,
to:2101,
rp:0,
rpa:0,
mdi:'si1099c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1107',
retainState:false,
immo:false,
apsn:'Slide1081',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1107',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1099c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1099,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1099',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1115,
tsp:50,
ip:'dr/01115.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide1081:{
lb:'Simulation slide 11',
id:1081,
from:2102,
to:2146,
iols:0,
i360qs:false,
sdu:1.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1081c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1107',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1081c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1081,
dn:'Slide1081',
visible:'1'
},
si1144:{
name:'Simulation_11',
type:1268,
from:2147,
to:2146,
rp:0,
rpa:0,
mdi:'si1144c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1118',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1136',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1144c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1144,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1144',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1136:{
name:'Simulation_non_responsive_11',
type:1268,
from:2147,
to:2146,
rp:0,
rpa:0,
mdi:'si1136c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si1144',
retainState:false,
immo:false,
apsn:'Slide1118',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1144',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1136c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1136,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1136',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1152,
tsp:50,
ip:'dr/01152.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide1118:{
lb:'Simulation slide 12',
id:1118,
from:2147,
to:2189,
iols:0,
i360qs:false,
sdu:1.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1118c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1144',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide1118c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1118,
dn:'Slide1118',
visible:'1'
},
si1181:{
name:'Simulation_12',
type:1268,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1181c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1173',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1181c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1181,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1181',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1173:{
name:'Simulation_non_responsive_12',
type:1268,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1173c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1181',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1192',
t:1269
}
,{
n:'si1212',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1181',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1173c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1173,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1173',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1189,
tsp:50,
ip:'dr/01189.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1192:{
name:'Click_box_5',
type:1269,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1192c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":884,"left":137,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1173',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1265);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:10.177,
lcapid:'si1212',
si:[{
n:'si1202',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1192]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1192c:{
b:[137,884,171,904],
fh:false,
fw:false,
uid:1192,
iso:false,
css:{
360:{
l:'14.095%',
t:'145.395%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'14.095%',
lhID:-1,
lvEID:0,
lvV:'145.395%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'14.095%',
t:'145.395%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'14.095%',
lhID:-1,
lvEID:0,
lvV:'145.395%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'14.095%',
t:'145.395%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'14.095%',
lhID:-1,
lvEID:0,
lvV:'145.395%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1192',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[137,884,171,904],
vb:[137,884,171,904]
},
si1202:{
name:'Shape_5',
type:612,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1202c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1202]
}
]
,
stis:0,
bstiid:1192,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1192',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1202c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1202,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1202',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1212:{
name:'Rectangle_5',
type:612,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1212c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":944,"left":152,"width":300,"height":"auto"}}',
parentGroup:'si1173',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1223,
stt:0,
dsr:'Default_State',
stsi:[1212]
}
,{
stn:1235,
stt:102,
dsr:'Failure',
stsi:[1236]
}
,{
stn:1246,
stt:103,
dsr:'Hint',
stsi:[1247]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1212','si1225','si1236','si1247'],
isDD:false
},
si1212c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1212,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1212',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1225:{
name:'',
type:612,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1225c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":944,"left":152,"width":300,"height":"auto"}}',
parentGroup:'si1173',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1212',
stl:[{
stn:'Normal',
stt:0,
stsi:[1225]
}
]
,
stis:0,
bstiid:1212,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1212,
isDD:false
},
si1225c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1225,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1225',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1236:{
name:'',
type:612,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1236c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":944,"left":152,"width":300,"height":"auto"}}',
parentGroup:'si1173',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1212',
stl:[{
stn:'Normal',
stt:0,
stsi:[1236]
}
]
,
stis:0,
bstiid:1212,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1212,
isDD:false
},
si1236c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1236,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1236',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1247:{
name:'',
type:612,
from:2190,
to:2495,
rp:0,
rpa:0,
mdi:'si1247c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:10.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":944,"left":152,"width":300,"height":"auto"}}',
parentGroup:'si1173',
retainState:false,
immo:false,
apsn:'Slide1155',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1212',
stl:[{
stn:'Normal',
stt:0,
stsi:[1247]
}
]
,
stis:0,
bstiid:1212,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1212,
isDD:false
},
si1247c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1247,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1247',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1155:{
lb:'Simulation slide 13',
id:1155,
from:2190,
to:2495,
iols:0,
i360qs:false,
sdu:10.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1155c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1181',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1265:{
ts:''
}

}

},
Slide1155c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1155,
dn:'Slide1155',
visible:'1'
},
si1298:{
name:'Simulation_13',
type:1268,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1298c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1290',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1298c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1298,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1298',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1290:{
name:'Simulation_non_responsive_13',
type:1268,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1290c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1298',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1309',
t:1269
}
,{
n:'si1329',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1298',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1290c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1290,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1290',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1306,
tsp:50,
ip:'dr/01306.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1309:{
name:'Click_box_6',
type:1269,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1309c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":943,"left":132,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1290',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1382);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:2.70901,
lcapid:'si1329',
si:[{
n:'si1319',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1309]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1309c:{
b:[132,943,166,963],
fh:false,
fw:false,
uid:1309,
iso:false,
css:{
360:{
l:'13.580%',
t:'155.099%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'13.580%',
lhID:-1,
lvEID:0,
lvV:'155.099%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'13.580%',
t:'155.099%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'13.580%',
lhID:-1,
lvEID:0,
lvV:'155.099%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'13.580%',
t:'155.099%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'13.580%',
lhID:-1,
lvEID:0,
lvV:'155.099%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1309',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[132,943,166,963],
vb:[132,943,166,963]
},
si1319:{
name:'Shape_6',
type:612,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1319c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1319]
}
]
,
stis:0,
bstiid:1309,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1309',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1319c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1319,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1319',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1329:{
name:'Rectangle_6',
type:612,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1329c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1003,"left":147,"width":300,"height":"auto"}}',
parentGroup:'si1290',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1340,
stt:0,
dsr:'Default_State',
stsi:[1329]
}
,{
stn:1352,
stt:102,
dsr:'Failure',
stsi:[1353]
}
,{
stn:1363,
stt:103,
dsr:'Hint',
stsi:[1364]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1329','si1342','si1353','si1364'],
isDD:false
},
si1329c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1329,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1329',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1342:{
name:'',
type:612,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1342c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1003,"left":147,"width":300,"height":"auto"}}',
parentGroup:'si1290',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1329',
stl:[{
stn:'Normal',
stt:0,
stsi:[1342]
}
]
,
stis:0,
bstiid:1329,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1329,
isDD:false
},
si1342c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1342,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1342',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1353:{
name:'',
type:612,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1353c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1003,"left":147,"width":300,"height":"auto"}}',
parentGroup:'si1290',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1329',
stl:[{
stn:'Normal',
stt:0,
stsi:[1353]
}
]
,
stis:0,
bstiid:1329,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1329,
isDD:false
},
si1353c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1353,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1353',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1364:{
name:'',
type:612,
from:2496,
to:2577,
rp:0,
rpa:0,
mdi:'si1364c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1003,"left":147,"width":300,"height":"auto"}}',
parentGroup:'si1290',
retainState:false,
immo:false,
apsn:'Slide1272',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1329',
stl:[{
stn:'Normal',
stt:0,
stsi:[1364]
}
]
,
stis:0,
bstiid:1329,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1329,
isDD:false
},
si1364c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1364,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1364',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1272:{
lb:'Simulation slide 14',
id:1272,
from:2496,
to:2577,
iols:0,
i360qs:false,
sdu:2.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1272c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1298',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1382:{
ts:''
}

}

},
Slide1272c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1272,
dn:'Slide1272',
visible:'1'
},
si1415:{
name:'Simulation_14',
type:1268,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1415c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1407',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1415c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1415,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1415',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1407:{
name:'Simulation_non_responsive_14',
type:1268,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1407c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1415',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1426',
t:1269
}
,{
n:'si1446',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1415',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1407c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1407,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1407',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1423,
tsp:50,
ip:'dr/01423.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1426:{
name:'Click_box_7',
type:1269,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1426c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":1001,"left":115,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1407',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1499);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.09701,
lcapid:'si1446',
si:[{
n:'si1436',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1426]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1426c:{
b:[115,1001,149,1021],
fh:false,
fw:false,
uid:1426,
iso:false,
css:{
360:{
l:'11.831%',
t:'164.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'164.638%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'11.831%',
t:'164.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'164.638%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'11.831%',
t:'164.638%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'11.831%',
lhID:-1,
lvEID:0,
lvV:'164.638%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1426',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[115,1001,149,1021],
vb:[115,1001,149,1021]
},
si1436:{
name:'Shape_7',
type:612,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1436c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1436]
}
]
,
stis:0,
bstiid:1426,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1426',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1436c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1436,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1436',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1446:{
name:'Rectangle_7',
type:612,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1446c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1061,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si1407',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1457,
stt:0,
dsr:'Default_State',
stsi:[1446]
}
,{
stn:1469,
stt:102,
dsr:'Failure',
stsi:[1470]
}
,{
stn:1480,
stt:103,
dsr:'Hint',
stsi:[1481]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1446','si1459','si1470','si1481'],
isDD:false
},
si1446c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1446,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1446',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1459:{
name:'',
type:612,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1459c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1061,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si1407',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1446',
stl:[{
stn:'Normal',
stt:0,
stsi:[1459]
}
]
,
stis:0,
bstiid:1446,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1446,
isDD:false
},
si1459c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1459,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1459',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1470:{
name:'',
type:612,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1470c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1061,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si1407',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1446',
stl:[{
stn:'Normal',
stt:0,
stsi:[1470]
}
]
,
stis:0,
bstiid:1446,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1446,
isDD:false
},
si1470c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1470,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1470',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1481:{
name:'',
type:612,
from:2578,
to:2611,
rp:0,
rpa:0,
mdi:'si1481c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1061,"left":130,"width":300,"height":"auto"}}',
parentGroup:'si1407',
retainState:false,
immo:false,
apsn:'Slide1389',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1446',
stl:[{
stn:'Normal',
stt:0,
stsi:[1481]
}
]
,
stis:0,
bstiid:1446,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1446,
isDD:false
},
si1481c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1481,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1481',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1389:{
lb:'Simulation slide 15',
id:1389,
from:2578,
to:2611,
iols:0,
i360qs:false,
sdu:1.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1389c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1415',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1499:{
ts:''
}

}

},
Slide1389c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1389,
dn:'Slide1389',
visible:'1'
},
si1532:{
name:'Simulation_15',
type:1268,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1532c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1524',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1532c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1532,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1532',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1524:{
name:'Simulation_non_responsive_15',
type:1268,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1524c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1532',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1543',
t:1269
}
,{
n:'si1563',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1532',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1524c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1524,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1524',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1540,
tsp:50,
ip:'dr/01540.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1543:{
name:'Click_box_8',
type:1269,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1543c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":798,"left":199,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1524',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1616);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.48401,
lcapid:'si1563',
si:[{
n:'si1553',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1543]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1543c:{
b:[199,798,233,818],
fh:false,
fw:false,
uid:1543,
iso:false,
css:{
360:{
l:'20.473%',
t:'131.250%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'20.473%',
lhID:-1,
lvEID:0,
lvV:'131.250%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'20.473%',
t:'131.250%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'20.473%',
lhID:-1,
lvEID:0,
lvV:'131.250%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'20.473%',
t:'131.250%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'20.473%',
lhID:-1,
lvEID:0,
lvV:'131.250%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1543',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[199,798,233,818],
vb:[199,798,233,818]
},
si1553:{
name:'Shape_8',
type:612,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1553c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1553]
}
]
,
stis:0,
bstiid:1543,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1543',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1553c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1553,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1553',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1563:{
name:'Rectangle_8',
type:612,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1563c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":858,"left":214,"width":300,"height":"auto"}}',
parentGroup:'si1524',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1574,
stt:0,
dsr:'Default_State',
stsi:[1563]
}
,{
stn:1586,
stt:102,
dsr:'Failure',
stsi:[1587]
}
,{
stn:1597,
stt:103,
dsr:'Hint',
stsi:[1598]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1563','si1576','si1587','si1598'],
isDD:false
},
si1563c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1563,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1563',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1576:{
name:'',
type:612,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1576c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":858,"left":214,"width":300,"height":"auto"}}',
parentGroup:'si1524',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1563',
stl:[{
stn:'Normal',
stt:0,
stsi:[1576]
}
]
,
stis:0,
bstiid:1563,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1563,
isDD:false
},
si1576c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1576,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1576',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1587:{
name:'',
type:612,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1587c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":858,"left":214,"width":300,"height":"auto"}}',
parentGroup:'si1524',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1563',
stl:[{
stn:'Normal',
stt:0,
stsi:[1587]
}
]
,
stis:0,
bstiid:1563,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1563,
isDD:false
},
si1587c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1587,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1587',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1598:{
name:'',
type:612,
from:2612,
to:2656,
rp:0,
rpa:0,
mdi:'si1598c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.5,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":858,"left":214,"width":300,"height":"auto"}}',
parentGroup:'si1524',
retainState:false,
immo:false,
apsn:'Slide1506',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1563',
stl:[{
stn:'Normal',
stt:0,
stsi:[1598]
}
]
,
stis:0,
bstiid:1563,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1563,
isDD:false
},
si1598c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1598,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1598',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1506:{
lb:'Simulation slide 16',
id:1506,
from:2612,
to:2656,
iols:0,
i360qs:false,
sdu:1.5,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1506c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1532',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1616:{
ts:''
}

}

},
Slide1506c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1506,
dn:'Slide1506',
visible:'1'
},
si1649:{
name:'Simulation_16',
type:1268,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1649c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1641',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1649c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1649,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1649',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1641:{
name:'Simulation_non_responsive_16',
type:1268,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1641c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1649',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1660',
t:1269
}
,{
n:'si1680',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1649',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1641c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1641,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1641',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1657,
tsp:50,
ip:'dr/01657.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1660:{
name:'Click_box_9',
type:1269,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1660c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":948,"left":688,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1641',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1733);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:6.38001,
lcapid:'si1680',
si:[{
n:'si1670',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1660]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1660c:{
b:[688,948,722,968],
fh:false,
fw:false,
uid:1660,
iso:false,
css:{
360:{
l:'70.782%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.782%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'70.782%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.782%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'70.782%',
t:'155.921%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'70.782%',
lhID:-1,
lvEID:0,
lvV:'155.921%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1660',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[688,948,722,968],
vb:[688,948,722,968]
},
si1670:{
name:'Shape_9',
type:612,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1670c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1670]
}
]
,
stis:0,
bstiid:1660,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1660',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1670c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:1670,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1670',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si1680:{
name:'Rectangle_9',
type:612,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1680c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1008,"left":703,"width":300,"height":"auto"}}',
parentGroup:'si1641',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1691,
stt:0,
dsr:'Default_State',
stsi:[1680]
}
,{
stn:1703,
stt:102,
dsr:'Failure',
stsi:[1704]
}
,{
stn:1714,
stt:103,
dsr:'Hint',
stsi:[1715]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1680','si1693','si1704','si1715'],
isDD:false
},
si1680c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1680,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1680',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1693:{
name:'',
type:612,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1693c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1008,"left":703,"width":300,"height":"auto"}}',
parentGroup:'si1641',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1680',
stl:[{
stn:'Normal',
stt:0,
stsi:[1693]
}
]
,
stis:0,
bstiid:1680,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1680,
isDD:false
},
si1693c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1693,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1693',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1704:{
name:'',
type:612,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1704c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1008,"left":703,"width":300,"height":"auto"}}',
parentGroup:'si1641',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1680',
stl:[{
stn:'Normal',
stt:0,
stsi:[1704]
}
]
,
stis:0,
bstiid:1680,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1680,
isDD:false
},
si1704c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1704,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1704',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1715:{
name:'',
type:612,
from:2657,
to:2848,
rp:0,
rpa:0,
mdi:'si1715c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.4,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":1008,"left":703,"width":300,"height":"auto"}}',
parentGroup:'si1641',
retainState:false,
immo:false,
apsn:'Slide1623',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1680',
stl:[{
stn:'Normal',
stt:0,
stsi:[1715]
}
]
,
stis:0,
bstiid:1680,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1680,
isDD:false
},
si1715c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1715,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1715',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1623:{
lb:'Simulation slide 17',
id:1623,
from:2657,
to:2848,
iols:0,
i360qs:false,
sdu:6.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1623c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1649',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1733:{
ts:''
}

}

},
Slide1623c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1623,
dn:'Slide1623',
visible:'1'
},
si1766:{
name:'Simulation_17',
type:1268,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1766c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1758',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1766c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1766,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1766',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1758:{
name:'Simulation_non_responsive_17',
type:1268,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1758c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1766',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1777',
t:1269
}
,{
n:'si1797',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1766',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1758c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1758,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1758',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1774,
tsp:50,
ip:'dr/01774.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1777:{
name:'Click_box_10',
type:1269,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1777c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":12,"left":186,"width":941,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1758',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1850);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:13.713,
lcapid:'si1797',
si:[{
n:'si1787',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1777]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1777c:{
b:[186,12,1127,62],
fh:false,
fw:false,
uid:1777,
iso:false,
css:{
360:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1777',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[186,12,1127,62],
vb:[186,12,1127,62]
},
si1787:{
name:'Shape_10',
type:612,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1787c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1787]
}
]
,
stis:0,
bstiid:1777,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1777',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1787c:{
b:[0,0,941,50],
fh:false,
fw:false,
uid:1787,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1787',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,943,52],
vb:[-2,-2,943,52]
},
si1797:{
name:'Rectangle_10',
type:612,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1797c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1758',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1808,
stt:0,
dsr:'Default_State',
stsi:[1797]
}
,{
stn:1820,
stt:102,
dsr:'Failure',
stsi:[1821]
}
,{
stn:1831,
stt:103,
dsr:'Hint',
stsi:[1832]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1797','si1810','si1821','si1832'],
isDD:false
},
si1797c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1797,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1797',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1810:{
name:'',
type:612,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1810c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1758',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1797',
stl:[{
stn:'Normal',
stt:0,
stsi:[1810]
}
]
,
stis:0,
bstiid:1797,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1797,
isDD:false
},
si1810c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1810,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1810',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1821:{
name:'',
type:612,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1821c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1758',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1797',
stl:[{
stn:'Normal',
stt:0,
stsi:[1821]
}
]
,
stis:0,
bstiid:1797,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1797,
isDD:false
},
si1821c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1821,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1821',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1832:{
name:'',
type:612,
from:2849,
to:3260,
rp:0,
rpa:0,
mdi:'si1832c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:13.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1758',
retainState:false,
immo:false,
apsn:'Slide1740',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1797',
stl:[{
stn:'Normal',
stt:0,
stsi:[1832]
}
]
,
stis:0,
bstiid:1797,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1797,
isDD:false
},
si1832c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1832,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1832',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1740:{
lb:'Simulation slide 18',
id:1740,
from:2849,
to:3260,
iols:0,
i360qs:false,
sdu:13.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1740c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1766',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1850:{
ts:''
}

}

},
Slide1740c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1740,
dn:'Slide1740',
visible:'1'
},
si1883:{
name:'Simulation_18',
type:1268,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1883c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1875',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1883c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1883,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1883',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1875:{
name:'Simulation_non_responsive_18',
type:1268,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1875c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si1883',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1894',
t:1269
}
,{
n:'si1914',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1883',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1875c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1875,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1875',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:1891,
tsp:50,
ip:'dr/01891.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1894:{
name:'Click_box_11',
type:1269,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1894c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":12,"left":186,"width":941,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1875',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(1967);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.60102,
lcapid:'si1914',
si:[{
n:'si1904',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1894]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1894c:{
b:[186,12,1127,62],
fh:false,
fw:false,
uid:1894,
iso:false,
css:{
360:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1894',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[186,12,1127,62],
vb:[186,12,1127,62]
},
si1904:{
name:'Shape_11',
type:612,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1904c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1904]
}
]
,
stis:0,
bstiid:1894,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si1894',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si1904c:{
b:[0,0,941,50],
fh:false,
fw:false,
uid:1904,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1904',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,943,52],
vb:[-2,-2,943,52]
},
si1914:{
name:'Rectangle_11',
type:612,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1914c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1875',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:1925,
stt:0,
dsr:'Default_State',
stsi:[1914]
}
,{
stn:1937,
stt:102,
dsr:'Failure',
stsi:[1938]
}
,{
stn:1948,
stt:103,
dsr:'Hint',
stsi:[1949]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si1914','si1927','si1938','si1949'],
isDD:false
},
si1914c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1914,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1914',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1927:{
name:'',
type:612,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1927c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1875',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1914',
stl:[{
stn:'Normal',
stt:0,
stsi:[1927]
}
]
,
stis:0,
bstiid:1914,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1914,
isDD:false
},
si1927c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1927,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1927',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1938:{
name:'',
type:612,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1938c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1875',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1914',
stl:[{
stn:'Normal',
stt:0,
stsi:[1938]
}
]
,
stis:0,
bstiid:1914,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1914,
isDD:false
},
si1938c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1938,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1938',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si1949:{
name:'',
type:612,
from:3261,
to:3489,
rp:0,
rpa:0,
mdi:'si1949c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si1875',
retainState:false,
immo:false,
apsn:'Slide1857',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si1914',
stl:[{
stn:'Normal',
stt:0,
stsi:[1949]
}
]
,
stis:0,
bstiid:1914,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:1914,
isDD:false
},
si1949c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:1949,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1949',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1857:{
lb:'Simulation slide 19',
id:1857,
from:3261,
to:3489,
iols:0,
i360qs:false,
sdu:7.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1857c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si1883',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1967:{
ts:''
}

}

},
Slide1857c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1857,
dn:'Slide1857',
visible:'1'
},
si2000:{
name:'Simulation_19',
type:1268,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2000c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1992',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2000c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2000,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2000',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1992:{
name:'Simulation_non_responsive_19',
type:1268,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si1992c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2000',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2011',
t:1269
}
,{
n:'si2031',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2000',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1992c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1992,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1992',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2008,
tsp:50,
ip:'dr/02008.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2011:{
name:'Click_box_12',
type:1269,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2011c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":69,"left":285,"width":644,"height":39},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si1992',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2084);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.66202,
lcapid:'si2031',
si:[{
n:'si2021',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2011]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2011c:{
b:[285,69,929,108],
fh:false,
fw:false,
uid:2011,
iso:false,
css:{
360:{
l:'29.321%',
t:'11.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'29.321%',
lhID:-1,
lvEID:0,
lvV:'11.349%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'29.321%',
t:'11.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'29.321%',
lhID:-1,
lvEID:0,
lvV:'11.349%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'29.321%',
t:'11.349%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'29.321%',
lhID:-1,
lvEID:0,
lvV:'11.349%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2011',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[285,69,929,108],
vb:[285,69,929,108]
},
si2021:{
name:'Shape_12',
type:612,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2021c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2021]
}
]
,
stis:0,
bstiid:2011,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2011',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2021c:{
b:[0,0,644,39],
fh:false,
fw:false,
uid:2021,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'66.255%',
h:'6.414%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2021',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,646,41],
vb:[-2,-2,646,41]
},
si2031:{
name:'Rectangle_12',
type:612,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2031c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":129,"left":300,"width":300,"height":"auto"}}',
parentGroup:'si1992',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2042,
stt:0,
dsr:'Default_State',
stsi:[2031]
}
,{
stn:2054,
stt:102,
dsr:'Failure',
stsi:[2055]
}
,{
stn:2065,
stt:103,
dsr:'Hint',
stsi:[2066]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2031','si2044','si2055','si2066'],
isDD:false
},
si2031c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2031,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2031',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2044:{
name:'',
type:612,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2044c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":129,"left":300,"width":300,"height":"auto"}}',
parentGroup:'si1992',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2031',
stl:[{
stn:'Normal',
stt:0,
stsi:[2044]
}
]
,
stis:0,
bstiid:2031,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2031,
isDD:false
},
si2044c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2044,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2044',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2055:{
name:'',
type:612,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2055c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":129,"left":300,"width":300,"height":"auto"}}',
parentGroup:'si1992',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2031',
stl:[{
stn:'Normal',
stt:0,
stsi:[2055]
}
]
,
stis:0,
bstiid:2031,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2031,
isDD:false
},
si2055c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2055,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2055',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2066:{
name:'',
type:612,
from:3490,
to:3540,
rp:0,
rpa:0,
mdi:'si2066c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.7,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":129,"left":300,"width":300,"height":"auto"}}',
parentGroup:'si1992',
retainState:false,
immo:false,
apsn:'Slide1974',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2031',
stl:[{
stn:'Normal',
stt:0,
stsi:[2066]
}
]
,
stis:0,
bstiid:2031,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2031,
isDD:false
},
si2066c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2066,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2066',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide1974:{
lb:'Simulation slide 20',
id:1974,
from:3490,
to:3540,
iols:0,
i360qs:false,
sdu:1.7,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1974c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2000',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2084:{
ts:''
}

}

},
Slide1974c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1974,
dn:'Slide1974',
visible:'1'
},
si2117:{
name:'Simulation_20',
type:1268,
from:3541,
to:3540,
rp:0,
rpa:0,
mdi:'si2117c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2091',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2109',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2117c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2117,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2117',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2109:{
name:'Simulation_non_responsive_20',
type:1268,
from:3541,
to:3540,
rp:0,
rpa:0,
mdi:'si2109c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2117',
retainState:false,
immo:false,
apsn:'Slide2091',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2117',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2109c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2109,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2109',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2125,
tsp:50,
ip:'dr/02125.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide2091:{
lb:'Simulation slide 21',
id:2091,
from:3541,
to:3582,
iols:0,
i360qs:false,
sdu:1.4,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2091c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2117',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2091c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2091,
dn:'Slide2091',
visible:'1'
},
si2154:{
name:'Simulation_21',
type:1268,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2154c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2146',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2154c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2154,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2154',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2146:{
name:'Simulation_non_responsive_21',
type:1268,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2146c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2154',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2162',
t:1269
}
,{
n:'si2182',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2154',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2146c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2146,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2146',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2125,
tsp:50,
ip:'dr/02125.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2162:{
name:'Click_box_13',
type:1269,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2162c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":174,"left":1284,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2146',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2235);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.59102,
lcapid:'si2182',
si:[{
n:'si2172',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2162]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2162c:{
b:[1284,174,1318,194],
fh:false,
fw:false,
uid:2162,
iso:false,
css:{
360:{
l:'132.099%',
t:'28.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.099%',
lhID:-1,
lvEID:0,
lvV:'28.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'132.099%',
t:'28.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.099%',
lhID:-1,
lvEID:0,
lvV:'28.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'132.099%',
t:'28.618%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'132.099%',
lhID:-1,
lvEID:0,
lvV:'28.618%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2162',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1284,174,1318,194],
vb:[1284,174,1318,194]
},
si2172:{
name:'Shape_13',
type:612,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2172c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2172]
}
]
,
stis:0,
bstiid:2162,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2162',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2172c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2172,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2172',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2182:{
name:'Rectangle_13',
type:612,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2182c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":234,"left":969,"width":300,"height":"auto"}}',
parentGroup:'si2146',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2193,
stt:0,
dsr:'Default_State',
stsi:[2182]
}
,{
stn:2205,
stt:102,
dsr:'Failure',
stsi:[2206]
}
,{
stn:2216,
stt:103,
dsr:'Hint',
stsi:[2217]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2182','si2195','si2206','si2217'],
isDD:false
},
si2182c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2182,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2182',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2195:{
name:'',
type:612,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2195c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":234,"left":969,"width":300,"height":"auto"}}',
parentGroup:'si2146',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2182',
stl:[{
stn:'Normal',
stt:0,
stsi:[2195]
}
]
,
stis:0,
bstiid:2182,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2182,
isDD:false
},
si2195c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2195,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2195',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2206:{
name:'',
type:612,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2206c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":234,"left":969,"width":300,"height":"auto"}}',
parentGroup:'si2146',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2182',
stl:[{
stn:'Normal',
stt:0,
stsi:[2206]
}
]
,
stis:0,
bstiid:2182,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2182,
isDD:false
},
si2206c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2206,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2206',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2217:{
name:'',
type:612,
from:3583,
to:3631,
rp:0,
rpa:0,
mdi:'si2217c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":234,"left":969,"width":300,"height":"auto"}}',
parentGroup:'si2146',
retainState:false,
immo:false,
apsn:'Slide2128',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2182',
stl:[{
stn:'Normal',
stt:0,
stsi:[2217]
}
]
,
stis:0,
bstiid:2182,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2182,
isDD:false
},
si2217c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2217,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2217',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2128:{
lb:'Simulation slide 22',
id:2128,
from:3583,
to:3631,
iols:0,
i360qs:false,
sdu:1.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2128c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2154',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2235:{
ts:''
}

}

},
Slide2128c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2128,
dn:'Slide2128',
visible:'1'
},
si2268:{
name:'Simulation_22',
type:1268,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2268c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2260',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2268c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2268,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2268',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2260:{
name:'Simulation_non_responsive_22',
type:1268,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2260c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2268',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2279',
t:1269
}
,{
n:'si2299',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2268',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2260c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2260,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2260',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2276,
tsp:50,
ip:'dr/02276.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2279:{
name:'Click_box_14',
type:1269,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2279c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":12,"left":186,"width":941,"height":50},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2260',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2352);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:1.57602,
lcapid:'si2299',
si:[{
n:'si2289',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2279]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2279c:{
b:[186,12,1127,62],
fh:false,
fw:false,
uid:2279,
iso:false,
css:{
360:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'19.136%',
t:'1.974%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'19.136%',
lhID:-1,
lvEID:0,
lvV:'1.974%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2279',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[186,12,1127,62],
vb:[186,12,1127,62]
},
si2289:{
name:'Shape_14',
type:612,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2289c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2289]
}
]
,
stis:0,
bstiid:2279,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2279',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2289c:{
b:[0,0,941,50],
fh:false,
fw:false,
uid:2289,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'96.811%',
h:'8.224%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2289',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,943,52],
vb:[-2,-2,943,52]
},
si2299:{
name:'Rectangle_14',
type:612,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2299c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si2260',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2310,
stt:0,
dsr:'Default_State',
stsi:[2299]
}
,{
stn:2322,
stt:102,
dsr:'Failure',
stsi:[2323]
}
,{
stn:2333,
stt:103,
dsr:'Hint',
stsi:[2334]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2299','si2312','si2323','si2334'],
isDD:false
},
si2299c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2299,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2299',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2312:{
name:'',
type:612,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2312c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si2260',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2299',
stl:[{
stn:'Normal',
stt:0,
stsi:[2312]
}
]
,
stis:0,
bstiid:2299,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2299,
isDD:false
},
si2312c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2312,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2312',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2323:{
name:'',
type:612,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2323c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si2260',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2299',
stl:[{
stn:'Normal',
stt:0,
stsi:[2323]
}
]
,
stis:0,
bstiid:2299,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2299,
isDD:false
},
si2323c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2323,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2323',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2334:{
name:'',
type:612,
from:3632,
to:3679,
rp:0,
rpa:0,
mdi:'si2334c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:1.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":72,"left":201,"width":300,"height":"auto"}}',
parentGroup:'si2260',
retainState:false,
immo:false,
apsn:'Slide2242',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2299',
stl:[{
stn:'Normal',
stt:0,
stsi:[2334]
}
]
,
stis:0,
bstiid:2299,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2299,
isDD:false
},
si2334c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2334,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2334',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2242:{
lb:'Simulation slide 23',
id:2242,
from:3632,
to:3679,
iols:0,
i360qs:false,
sdu:1.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2242c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2268',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2352:{
ts:''
}

}

},
Slide2242c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2242,
dn:'Slide2242',
visible:'1'
},
si2385:{
name:'Simulation_23',
type:1268,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2385c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2377',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2385c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2385,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2385',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2377:{
name:'Simulation_non_responsive_23',
type:1268,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2377c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2385',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2393',
t:1269
}
,{
n:'si2413',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2385',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2377c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2377,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2377',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2276,
tsp:50,
ip:'dr/02276.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2393:{
name:'Click_box_15',
type:1269,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2393c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":418,"left":815,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2377',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2466);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:5.59202,
lcapid:'si2413',
si:[{
n:'si2403',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2393]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2393c:{
b:[815,418,849,438],
fh:false,
fw:false,
uid:2393,
iso:false,
css:{
360:{
l:'83.848%',
t:'68.750%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'83.848%',
lhID:-1,
lvEID:0,
lvV:'68.750%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'83.848%',
t:'68.750%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'83.848%',
lhID:-1,
lvEID:0,
lvV:'68.750%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'83.848%',
t:'68.750%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'83.848%',
lhID:-1,
lvEID:0,
lvV:'68.750%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2393',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[815,418,849,438],
vb:[815,418,849,438]
},
si2403:{
name:'Shape_15',
type:612,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2403c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2403]
}
]
,
stis:0,
bstiid:2393,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2393',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2403c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2403,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2403',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2413:{
name:'Rectangle_15',
type:612,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2413c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":478,"left":830,"width":300,"height":"auto"}}',
parentGroup:'si2377',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2424,
stt:0,
dsr:'Default_State',
stsi:[2413]
}
,{
stn:2436,
stt:102,
dsr:'Failure',
stsi:[2437]
}
,{
stn:2447,
stt:103,
dsr:'Hint',
stsi:[2448]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2413','si2426','si2437','si2448'],
isDD:false
},
si2413c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2413,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2413',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2426:{
name:'',
type:612,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2426c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":478,"left":830,"width":300,"height":"auto"}}',
parentGroup:'si2377',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2413',
stl:[{
stn:'Normal',
stt:0,
stsi:[2426]
}
]
,
stis:0,
bstiid:2413,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2413,
isDD:false
},
si2426c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2426,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2426',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2437:{
name:'',
type:612,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2437c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":478,"left":830,"width":300,"height":"auto"}}',
parentGroup:'si2377',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2413',
stl:[{
stn:'Normal',
stt:0,
stsi:[2437]
}
]
,
stis:0,
bstiid:2413,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2413,
isDD:false
},
si2437c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2437,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2437',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2448:{
name:'',
type:612,
from:3680,
to:3848,
rp:0,
rpa:0,
mdi:'si2448c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:5.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":478,"left":830,"width":300,"height":"auto"}}',
parentGroup:'si2377',
retainState:false,
immo:false,
apsn:'Slide2359',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2413',
stl:[{
stn:'Normal',
stt:0,
stsi:[2448]
}
]
,
stis:0,
bstiid:2413,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2413,
isDD:false
},
si2448c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2448,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2448',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2359:{
lb:'Simulation slide 24',
id:2359,
from:3680,
to:3848,
iols:0,
i360qs:false,
sdu:5.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2359c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2385',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2466:{
ts:''
}

}

},
Slide2359c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2359,
dn:'Slide2359',
visible:'1'
},
si2536:{
name:'Simulation_25',
type:1268,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2536c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2528',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2536c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2536,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2528:{
name:'Simulation_non_responsive_25',
type:1268,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2528c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2536',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2547',
t:1269
}
,{
n:'si2567',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2536',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2528c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2528,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2528',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2544,
tsp:50,
ip:'dr/02544.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2547:{
name:'Click_box_16',
type:1269,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2547c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":417,"left":1088,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2528',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2620);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:2.56703,
lcapid:'si2567',
si:[{
n:'si2557',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2547]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2547c:{
b:[1088,417,1122,437],
fh:false,
fw:false,
uid:2547,
iso:false,
css:{
360:{
l:'111.934%',
t:'68.586%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'111.934%',
lhID:-1,
lvEID:0,
lvV:'68.586%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'111.934%',
t:'68.586%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'111.934%',
lhID:-1,
lvEID:0,
lvV:'68.586%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'111.934%',
t:'68.586%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'111.934%',
lhID:-1,
lvEID:0,
lvV:'68.586%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2547',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1088,417,1122,437],
vb:[1088,417,1122,437]
},
si2557:{
name:'Shape_16',
type:612,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2557c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2557]
}
]
,
stis:0,
bstiid:2547,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2547',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2557c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2557,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2557',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2567:{
name:'Rectangle_16',
type:612,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2567c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":477,"left":1103,"width":300,"height":"auto"}}',
parentGroup:'si2528',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2578,
stt:0,
dsr:'Default_State',
stsi:[2567]
}
,{
stn:2590,
stt:102,
dsr:'Failure',
stsi:[2591]
}
,{
stn:2601,
stt:103,
dsr:'Hint',
stsi:[2602]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2567','si2580','si2591','si2602'],
isDD:false
},
si2567c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2567,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2567',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2580:{
name:'',
type:612,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2580c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":477,"left":1103,"width":300,"height":"auto"}}',
parentGroup:'si2528',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2567',
stl:[{
stn:'Normal',
stt:0,
stsi:[2580]
}
]
,
stis:0,
bstiid:2567,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2567,
isDD:false
},
si2580c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2580,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2580',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2591:{
name:'',
type:612,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2591c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":477,"left":1103,"width":300,"height":"auto"}}',
parentGroup:'si2528',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2567',
stl:[{
stn:'Normal',
stt:0,
stsi:[2591]
}
]
,
stis:0,
bstiid:2567,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2567,
isDD:false
},
si2591c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2591,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2591',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2602:{
name:'',
type:612,
from:3849,
to:3926,
rp:0,
rpa:0,
mdi:'si2602c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:2.6,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":477,"left":1103,"width":300,"height":"auto"}}',
parentGroup:'si2528',
retainState:false,
immo:false,
apsn:'Slide2510',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2567',
stl:[{
stn:'Normal',
stt:0,
stsi:[2602]
}
]
,
stis:0,
bstiid:2567,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2567,
isDD:false
},
si2602c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2602,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2602',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2510:{
lb:'Simulation slide 26',
id:2510,
from:3849,
to:3926,
iols:0,
i360qs:false,
sdu:2.6,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2510c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2536',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2620:{
ts:''
}

}

},
Slide2510c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2510,
dn:'Slide2510',
visible:'1'
},
si2653:{
name:'Simulation_26',
type:1268,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2653c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2645',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2653c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2653,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2653',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2645:{
name:'Simulation_non_responsive_26',
type:1268,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2645c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2653',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2664',
t:1269
}
,{
n:'si2684',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2653',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2645c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2645,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2645',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2661,
tsp:50,
ip:'dr/02661.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2664:{
name:'Click_box_17',
type:1269,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2664c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":614,"left":1010,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2645',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2737);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:7.18802,
lcapid:'si2684',
si:[{
n:'si2674',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2664]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2664c:{
b:[1010,614,1044,634],
fh:false,
fw:false,
uid:2664,
iso:false,
css:{
360:{
l:'103.909%',
t:'100.987%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'100.987%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'103.909%',
t:'100.987%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'100.987%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'103.909%',
t:'100.987%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'103.909%',
lhID:-1,
lvEID:0,
lvV:'100.987%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2664',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[1010,614,1044,634],
vb:[1010,614,1044,634]
},
si2674:{
name:'Shape_17',
type:612,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2674c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2674]
}
]
,
stis:0,
bstiid:2664,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2664',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2674c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2674,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2674',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2684:{
name:'Rectangle_17',
type:612,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2684c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":674,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si2645',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2695,
stt:0,
dsr:'Default_State',
stsi:[2684]
}
,{
stn:2707,
stt:102,
dsr:'Failure',
stsi:[2708]
}
,{
stn:2718,
stt:103,
dsr:'Hint',
stsi:[2719]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2684','si2697','si2708','si2719'],
isDD:false
},
si2684c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2684,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2684',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2697:{
name:'',
type:612,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2697c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":674,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si2645',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2684',
stl:[{
stn:'Normal',
stt:0,
stsi:[2697]
}
]
,
stis:0,
bstiid:2684,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2684,
isDD:false
},
si2697c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2697,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2697',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2708:{
name:'',
type:612,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2708c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":674,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si2645',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2684',
stl:[{
stn:'Normal',
stt:0,
stsi:[2708]
}
]
,
stis:0,
bstiid:2684,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2684,
isDD:false
},
si2708c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2708,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2708',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2719:{
name:'',
type:612,
from:3927,
to:4142,
rp:0,
rpa:0,
mdi:'si2719c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:7.2,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":674,"left":1025,"width":300,"height":"auto"}}',
parentGroup:'si2645',
retainState:false,
immo:false,
apsn:'Slide2627',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2684',
stl:[{
stn:'Normal',
stt:0,
stsi:[2719]
}
]
,
stis:0,
bstiid:2684,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2684,
isDD:false
},
si2719c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2719,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2719',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2627:{
lb:'Simulation slide 27',
id:2627,
from:3927,
to:4142,
iols:0,
i360qs:false,
sdu:7.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2627c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2653',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2737:{
ts:''
}

}

},
Slide2627c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2627,
dn:'Slide2627',
visible:'1'
},
si2770:{
name:'Simulation_27',
type:1268,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2770c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2762',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2770c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2770,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2770',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2762:{
name:'Simulation_non_responsive_27',
type:1268,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2762c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
parentGroup:'si2770',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2781',
t:1269
}
,{
n:'si2801',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-clickbox":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-clickbox":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2770',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2762c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2762,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2762',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2778,
tsp:50,
ip:'dr/02778.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2781:{
name:'Click_box_18',
type:1269,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2781c',
tag:'slide-item-clickbox',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:13,
isOverridden:false
}
]
,
widgetProps:'{"isHighlightBox":false,"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clickbox_shape_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"0"}},"sizeNPos":{"top":757,"left":580,"width":34,"height":20},"attempts":1024,"showHandCursorOnClickableAreas":false}',
parentGroup:'si2762',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
wicb:'{"scripts":[{"then":[["cp.jumpToNextSlide(2854);"]]}]}',
iflbx:false,
ipflbx:true,
ihb:false,
ma:1024,
pa:4.84102,
lcapid:'si2801',
si:[{
n:'si2791',
t:612
}
]
,
te:false,
ie:false,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2781]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2781c:{
b:[580,757,614,777],
fh:false,
fw:false,
uid:2781,
iso:false,
css:{
360:{
l:'59.671%',
t:'124.507%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.671%',
lhID:-1,
lvEID:0,
lvV:'124.507%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'59.671%',
t:'124.507%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.671%',
lhID:-1,
lvEID:0,
lvV:'124.507%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'59.671%',
t:'124.507%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'59.671%',
lhID:-1,
lvEID:0,
lvV:'124.507%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2781',
visible:1,
effectiveVi:1,
JSONEffectData:false,
cur:0,
vbwr:[580,757,614,777],
vb:[580,757,614,777]
},
si2791:{
name:'Shape_18',
type:612,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2791c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"4k0dr","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100 % ","listSize":"100 % ","overridden":"false"}}],"entityMap":{}}',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2791]
}
]
,
stis:0,
bstiid:2781,
sipst:-1,
sicbs:false,
sihhs:false,
sihds:false,
parent:'si2781',
baseItemIdForPropertyFlow:-1,
isDD:false
},
si2791c:{
b:[0,0,34,20],
fh:false,
fw:false,
uid:2791,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.498%',
h:'3.289%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2791',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
path:'',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,36,22],
vb:[-2,-2,36,22]
},
si2801:{
name:'Rectangle_18',
type:612,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2801c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":817,"left":595,"width":300,"height":"auto"}}',
parentGroup:'si2762',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2812,
stt:0,
dsr:'Default_State',
stsi:[2801]
}
,{
stn:2824,
stt:102,
dsr:'Failure',
stsi:[2825]
}
,{
stn:2835,
stt:103,
dsr:'Hint',
stsi:[2836]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2801','si2814','si2825','si2836'],
isDD:false
},
si2801c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2801,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2801',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2814:{
name:'',
type:612,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2814c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":817,"left":595,"width":300,"height":"auto"}}',
parentGroup:'si2762',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2801',
stl:[{
stn:'Normal',
stt:0,
stsi:[2814]
}
]
,
stis:0,
bstiid:2801,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2801,
isDD:false
},
si2814c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2814,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2814',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2825:{
name:'',
type:612,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2825c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":817,"left":595,"width":300,"height":"auto"}}',
parentGroup:'si2762',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2801',
stl:[{
stn:'Normal',
stt:0,
stsi:[2825]
}
]
,
stis:0,
bstiid:2801,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2801,
isDD:false
},
si2825c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2825,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2825',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2836:{
name:'',
type:612,
from:4143,
to:4288,
rp:0,
rpa:0,
mdi:'si2836c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:4.9,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":817,"left":595,"width":300,"height":"auto"}}',
parentGroup:'si2762',
retainState:false,
immo:false,
apsn:'Slide2744',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2801',
stl:[{
stn:'Normal',
stt:0,
stsi:[2836]
}
]
,
stis:0,
bstiid:2801,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2801,
isDD:false
},
si2836c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2836,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2836',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2744:{
lb:'Simulation slide 28',
id:2744,
from:4143,
to:4288,
iols:0,
i360qs:false,
sdu:4.9,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2744c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2770',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2854:{
ts:''
}

}

},
Slide2744c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2744,
dn:'Slide2744',
visible:'1'
},
si2887:{
name:'Simulation_28',
type:1268,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2887c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2879',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2887c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2887,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2887',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2879:{
name:'Simulation_non_responsive_28',
type:1268,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2879c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-inputfield":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-inputfield":1},"canBeCard":false}',
parentGroup:'si2887',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2895',
t:2433
}
,{
n:'si2925',
t:612
}
]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false,"slide-item-inputfield":true},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0,"slide-item-inputfield":1},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2887',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2879c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2879,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:2778,
tsp:50,
ip:'dr/02778.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2895:{
name:'InputField_1',
type:2433,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2895c',
tag:'slide-item-inputfield',
v:0,
enabled:true,
defEn:true,
vu:[2923,2924],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:12,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"active":true,"disabled":false,"focusLost":true,"error":true},"scaleValue":"medium","currentState":"normal","isTextActive":true,"inputFieldProps":{"answersList":["1"],"enableCaseSensitive":true,"enableMultipleLine":false,"selectedInputFieldType":0},"normal":{"opacity":100,"editorState":{"blocks":[{"key":"3u77k","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"active":{"opacity":100,"editorState":{"blocks":[{"key":"t7ru","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_active","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"opacity":100,"editorState":{"blocks":[{"key":"s16q","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"focusLost":{"opacity":100,"editorState":{"blocks":[{"key":"1b65o","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_focusLost","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"error":{"opacity":100,"editorState":{"blocks":[{"key":"cducb","text":"Enter text here","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"textShadowColor:ffffff00"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"textShadowY:0px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":15,"style":"textShadowBlur:0px"},{"offset":0,"length":15,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"cp_inputField_shape_1_solid_style_error","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"designOption":"DEFAULT_INPUTFIELD_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"8"}},"size":{"small":{"desktop":{"textFontSize":16,"paddingSelectContainer":"9px 20px 6px 14px"},"tablet":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"},"mobile":{"textFontSize":18,"paddingSelectContainer":"12px 20px 8px 16px"}},"medium":{"desktop":{"textFontSize":20,"paddingSelectContainer":"11px 20px 8px 14px"},"tablet":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"},"mobile":{"textFontSize":22,"paddingSelectContainer":"14px 20px 10px 16px"}},"large":{"desktop":{"textFontSize":24,"paddingSelectContainer":"13px 20px 10px 14px"},"tablet":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"},"mobile":{"textFontSize":26,"paddingSelectContainer":"15px 20px 11px 16px"}}},"sizeNPos":{"top":0,"left":0,"width":165,"height":0},"attempts":1024}',
parentGroup:'si2879',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
ofov:'{"scripts":[{"then":[["cp.jumpToNextSlide(2972);"]]}]}',
iflbx:false,
ipflbx:true,
ifml:0,
ifcs:0,
ifst:0,
sz:1,
ifal:['1'],
si:[]
,
te:true,
ie:false,
lcapid:'si2925',
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2895]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2895c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2895,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2895',
visible:1,
effectiveVi:1,
JSONEffectData:false,
fa:100,
vbwr:[0,0,0,0],
vb:[0,0,0,0]
},
si2925:{
name:'Rectangle_19',
type:612,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2925c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'cp_default_caption_shape_solid_style',
presetType:0,
isOverridden:false
}
,{
presetId:'cp_default_quiz_caption_textinshape_style',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":60,"left":15,"width":300,"height":"auto"}}',
parentGroup:'si2879',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"b8kef","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","overridden":"false","presetId":"cp_default_quiz_caption_textinshape_style"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
stl:[{
stn:2936,
stt:0,
dsr:'Default_State',
stsi:[2925]
}
,{
stn:2948,
stt:102,
dsr:'Failure',
stsi:[2949]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
stc:['si2925','si2938','si2949','si2960'],
isDD:false
},
si2925c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2925,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2925',
visible:1,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:0,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2938:{
name:'',
type:612,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2938c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":60,"left":15,"width":300,"height":"auto"}}',
parentGroup:'si2879',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"e7msa","text":"Enter Success Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":55,"style":"overridden:false"},{"offset":0,"length":55,"style":"opacity:1"},{"offset":0,"length":55,"style":"backgroundColor:unset"},{"offset":0,"length":55,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":55,"style":"textHighlightEnable:false"},{"offset":0,"length":55,"style":"textOutlineEnable:false"},{"offset":0,"length":55,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_correct","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2925',
stl:[{
stn:'Normal',
stt:0,
stsi:[2938]
}
]
,
stis:0,
bstiid:2925,
sipst:101,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2925,
isDD:false
},
si2938c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2938,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2938',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2949:{
name:'',
type:612,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2949c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":60,"left":15,"width":300,"height":"auto"}}',
parentGroup:'si2879',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Failure Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2925',
stl:[{
stn:'Normal',
stt:0,
stsi:[2949]
}
]
,
stis:0,
bstiid:2925,
sipst:102,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2925,
isDD:false
},
si2949c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2949,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2949',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
si2960:{
name:'',
type:612,
from:4289,
to:4532,
rp:0,
rpa:0,
mdi:'si2960c',
tag:'',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:8.1,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
,{
presetId:'',
presetType:4,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"top":60,"left":15,"width":300,"height":"auto"}}',
parentGroup:'si2879',
retainState:false,
immo:false,
apsn:'Slide2861',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
vt:'',
rplm:{
360:0,
600:0,
972:0
}
,
rprm:{
360:0,
600:0,
972:0
}
,
rptm:{
360:0,
600:0,
972:0
}
,
rpbm:{
360:0,
600:0,
972:0
}
,
rpta:{
360:2,
600:2,
972:2
}
,
rptl:{
360:1,
600:1,
972:1
}
,
rpvt:{
360:{
vt:'',
text:''
}
,
600:{
vt:'',
text:''
}
,
972:{
vt:'',
text:''
}

}
,
subType:'',
text:'{"blocks":[{"key":"ah2dc","text":"Enter Hint Text","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"overridden:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#5EFF67"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-caption_incorrect","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
isc:1,
trin:0,
trout:0,
bstin:'si2925',
stl:[{
stn:'Normal',
stt:0,
stsi:[2960]
}
]
,
stis:0,
bstiid:2925,
sipst:103,
sicbs:true,
sihhs:false,
sihds:false,
baseItemIdForPropertyFlow:2925,
isDD:false
},
si2960c:{
b:[0,0,972,48],
fh:false,
fw:false,
uid:2960,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'100.000%',
h:'7.895%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2960',
visible:0,
effectiveVi:1,
JSONEffectData:false,
hms:false,
hme:false,
subt:1,
bc:'#c8e2ff',
fe:true,
fca:1,
fa:100,
path:'M 0.000000 0.000000 L 972.000000 0.000000 L 972.000000 48.000000 L 0.000000 48.000000 Z ',
svg:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-2,-2,974,50],
vb:[-2,-2,974,50]
},
Slide2861:{
lb:'Simulation slide 29',
id:2861,
from:4289,
to:4532,
iols:0,
i360qs:false,
sdu:8.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2861c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2887',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
2972:{
ts:''
}

}

},
Slide2861c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2861,
dn:'Slide2861',
visible:'1'
},
StAd5:{
from:4686,
to:9314,
src:'ar/StAd4.mp3',
du:155000,
saup:[{
sn:390,
del:0,
du:28.8,
l:false
}
,{
sn:507,
del:0,
du:2.9,
l:false
}
,{
sn:544,
del:0,
du:6.3,
l:false
}
,{
sn:661,
del:0,
du:2.6,
l:false
}
,{
sn:698,
del:0,
du:0.3,
l:false
}
,{
sn:735,
del:0,
du:0.7,
l:false
}
,{
sn:779,
del:0,
du:6.8,
l:false
}
,{
sn:813,
del:0,
du:10.8,
l:false
}
,{
sn:927,
del:0,
du:0.8,
l:false
}
,{
sn:964,
del:0,
du:10,
l:false
}
,{
sn:1081,
del:0,
du:1.5,
l:false
}
,{
sn:1118,
del:0,
du:1.4,
l:false
}
,{
sn:1155,
del:0,
du:10.2,
l:false
}
,{
sn:1272,
del:0,
du:2.7,
l:false
}
,{
sn:1389,
del:0,
du:1.1,
l:false
}
,{
sn:1506,
del:0,
du:1.5,
l:false
}
,{
sn:1623,
del:0,
du:6.4,
l:false
}
,{
sn:1740,
del:0,
du:13.7,
l:false
}
,{
sn:1857,
del:0,
du:7.6,
l:false
}
,{
sn:1974,
del:0,
du:1.7,
l:false
}
,{
sn:2091,
del:0,
du:1.4,
l:false
}
,{
sn:2128,
del:0,
du:1.6,
l:false
}
,{
sn:2242,
del:0,
du:1.6,
l:false
}
,{
sn:2359,
del:0,
du:5.6,
l:false
}
,{
sn:2510,
del:0,
du:2.6,
l:false
}
,{
sn:2627,
del:0,
du:7.2,
l:false
}
,{
sn:2744,
del:0,
du:4.9,
l:false
}
,{
sn:2861,
del:0,
du:8.1,
l:false
}
,{
sn:2973,
del:0,
du:4.2,
l:false
}
]

},
si2999:{
name:'Simulation_29',
type:1268,
from:4533,
to:4532,
rp:0,
rpa:0,
mdi:'si2999c',
tag:'container-simulation-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"autoFit":true}',
retainState:false,
immo:false,
apsn:'Slide2973',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2991',
t:1268
}
]
,
containerType:'simulation-widget',
widgetProps:'{"autoFit":true}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2999c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2999,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2999',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2991:{
name:'Simulation_non_responsive_29',
type:1268,
from:4533,
to:4532,
rp:0,
rpa:0,
mdi:'si2991c',
tag:'container-simulation-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
parentGroup:'si2999',
retainState:false,
immo:false,
apsn:'Slide2973',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'simulation-non-responsive',
widgetProps:'{"visibilityInfo":{"slide-item-clickbox":false,"slide-item-highlight-box":false,"slide-item-comment-box":false,"slide-item-inputfield":false,"slide-item-mouse-pointer":false},"sizeNPos":{"width":1440,"height":1080},"groupedItemsVisibility":{"slide-item-clickbox":0,"slide-item-highlight-box":0,"slide-item-comment-box":0,"slide-item-inputfield":0,"slide-item-mouse-pointer":0},"canBeCard":false}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2999',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2991c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2991,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2991',
visible:1,
effectiveVi:1,
JSONEffectData:false,
imgf:{
b:0,
c:0,
br:0,
o:100,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8'
}
,
tiletype:0,
extraImageProps:'',
tiletype:0,
imageFocus:0,
w:1440,
h:1080,
id:3007,
tsp:50,
ip:'dr/03007.bmp'
}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
Slide2973:{
lb:'Simulation slide 30',
id:2973,
from:4533,
to:4685,
iols:0,
i360qs:false,
sdu:5.1,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide2973c',
st:'Normal Slide',
sk:'Simulation',
slideTag:'',
type:30,
audCC:'""',
accProps:{
}
,
si:[{
n:'si2999',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide2973c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:2973,
dn:'Slide2973',
visible:'1'
},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var2923var2923:{
vid:2923,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
var2924var2924:{
vid:2924,
name:'variableEditBoxNum_1',
vv:0,
vvt:1,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var2923:'variableEditBoxStr_1',
var2924:'variableEditBoxNum_1'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1440,
h:1080,
iw:1440,
ih:1080,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'IST526 Lab 2 Citations.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{\\
  "--primary": "#F1EEE6",\\
\\
  "--color1": "#FFFFFF",\\
  "--color2": "#F8F7F4",\\
  "--color3": "#F1EEE6",\\
  "--color4": "#D6D5D1",\\
  "--color5": "#666666",\\
  "--color6": "#333333",\\
  "--color7": "#020C1C",\\
  "--colorC7": "#F7F7F7",\\
  "--disabledC12": "#989898",\\
  "--color1_light": "#FFCD74",\\
  "--color1_dark": "#C76D12",\\
  "--color2_light": "#86FFFF",\\
  "--color2_dark": "#00ACCC",\\
  "--color3_light": "#9B5DFF",\\
  "--color3_dark": "#0000CA",\\
  "--color4_light": "#99FF99",\\
  "--color4_dark": "#112FA7",\\
  "--color5_light": "#163EE5",\\
  "--color5_dark": "#00CB92",\\
  "--color6_light": "#7697FF",\\
  "--color6_dark": "#0040CB",\\
  "--color7_light": "#FF8E64",\\
  "--color7_dark": "#C5230B",\\
\\
  "--success": "#558564",\\
  "--error": "#C83E4D",\\
  "--hint": "#CB6F10",\\
  "--incomplete":"#E8BD2B",\\
  "--timeout": "#C74545",\\
  "--retry": "#CB6F10",\\
  "--white": "#ffffff",\\
  "--black": "#000000",\\
\\
  "--greyscale1": "#FFFFFF",\\
  "--greyscale2": "#F1EEE61F",\\
  "--greyscale3": "#B3B3B3",\\
  "--greyscale4": "#4B4B4B",\\
  "--greyscale5": "#333333",\\
  "--disabled": "#818181",\\
\\
  "--palette-color0": "var(--color1)",\\
  "--palette-color1": "var(--color2)",\\
  "--palette-color2": "var(--color3)",\\
  "--palette-color3": "var(--color4)",\\
  "--palette-color4": "var(--color5)",\\
  "--palette-color5": "var(--color6)",\\
  "--palette-color6": "var(--color7)",\\
  "--palette-color7": "var(--color5_light)",\\
  "--palette-color8": "var(--color4_dark)",\\
\\
  "--design-option-color1": "255, 255, 255",\\
  "--design-option-color2": "248, 247, 244",\\
  "--design-option-color3": "241, 238, 230",\\
  "--design-option-color4": "214, 213, 209",\\
  "--design-option-color5": "102, 102, 102",\\
  "--design-option-color6": "51, 51, 51",\\
  "--design-option-color7": "2, 12, 28",\\
  "--design-option-color5_light": "22, 62, 229",\\
  "--design-option-color4_dark": "17, 47, 167",\\
\\
  "--c1": "var(--design-option-color1)",\\
  "--c2": "var(--design-option-color2)",\\
  "--c3": "var(--design-option-color3)",\\
  "--c4": "var(--design-option-color4)",\\
  "--c5": "var(--design-option-color5)",\\
  "--c6": "var(--design-option-color6)",\\
  "--c7": "var(--design-option-color7)",\\
  "--c8": "var(--design-option-color5_light)",\\
  "--c9": "var(--design-option-color4_dark)",\\
  \\
  "--widget-container--fillcolor": "var(--palette-color1)",\\
\\
  "--font1": "Georgia",\\
  "--font2": "Arial",\\
  "--text-style-unset": "none",\\
\\
  "--text-heading-1--fontSize--desktop": "120px",\\
  "--text-heading-1--fontSize--tablet": "100px",\\
  "--text-heading-1--fontSize--mobile": "80px",\\
  "--text-heading-1--fontFamily": "var(--font1)",\\
  "--text-heading-1--fontWeight": "normal",\\
  "--text-heading-1--fontType": "regular",\\
  "--text-heading-1--fontStyle": "normal",\\
  "--text-heading-1--fontStretch": "normal",\\
  "--text-heading-1--lineHeight": "1.07",\\
  "--text-heading-1--marginLeft": "0px",\\
  "--text-heading-1--color": "var(--palette-color6)",\\
  "--text-heading-1--borderBottomStyle": "none",\\
  "--text-heading-1--textDecoration": "none",\\
  "--text-heading-1--letterSpacing": "-0.01",\\
  "--text-heading-1--textTransform": "none",\\
  "--text-heading-1--stroke": "var(--palette-color2)",\\
  "--text-heading-1--textAlign": "left",\\
  "--text-heading-1--justifyContent": "flex-start",\\
  "--text-heading-1--marginTop": "auto",\\
  "--text-heading-1--marginBottom": "0",\\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-2--fontSize--desktop": "80px",\\
  "--text-heading-2--fontSize--tablet": "72px",\\
  "--text-heading-2--fontSize--mobile": "60px",\\
  "--text-heading-2--fontFamily": "var(--font1)",\\
  "--text-heading-2--fontWeight": "normal",\\
  "--text-heading-2--fontType": "regular",\\
  "--text-heading-2--fontStyle": "normal",\\
  "--text-heading-2--fontStretch": "normal",\\
  "--text-heading-2--lineHeight": "1.1",\\
  "--text-heading-2--marginLeft": "0px",\\
  "--text-heading-2--color": "var(--palette-color6)",\\
  "--text-heading-2--borderBottomStyle": "none",\\
  "--text-heading-2--textDecoration": "none",\\
  "--text-heading-2--letterSpacing": "-0.04",\\
  "--text-heading-2--textTransform": "none",\\
  "--text-heading-2--stroke": "var(--palette-color2)",\\
  "--text-heading-2--textAlign": "left",\\
  "--text-heading-2--justifyContent": "flex-start",\\
  "--text-heading-2--marginTop": "auto",\\
  "--text-heading-2--marginBottom": "0",\\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-3--fontSize--desktop": "60px",\\
  "--text-heading-3--fontSize--tablet": "52px",\\
  "--text-heading-3--fontSize--mobile": "44px",\\
  "--text-heading-3--fontFamily": "var(--font1)",\\
  "--text-heading-3--fontWeight": "normal",\\
  "--text-heading-3--fontType": "regular",\\
  "--text-heading-3--fontStyle": "normal",\\
  "--text-heading-3--fontStretch": "normal",\\
  "--text-heading-3--lineHeight": "1.1",\\
  "--text-heading-3--marginLeft": "0px",\\
  "--text-heading-3--color": "var(--palette-color6)",\\
  "--text-heading-3--borderBottomStyle": "none",\\
  "--text-heading-3--textDecoration": "none",\\
  "--text-heading-3--letterSpacing": "0.03",\\
  "--text-heading-3--textTransform": "none",\\
  "--text-heading-3--stroke": "var(--palette-color2)",\\
  "--text-heading-3--textAlign": "left",\\
  "--text-heading-3--justifyContent": "flex-start",\\
  "--text-heading-3--marginTop": "auto",\\
  "--text-heading-3--marginBottom": "0",\\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-4--fontSize--desktop": "52px",\\
  "--text-heading-4--fontSize--tablet": "40px",\\
  "--text-heading-4--fontSize--mobile": "32px",\\
  "--text-heading-4--fontFamily": "var(--font1)",\\
  "--text-heading-4--fontWeight": "normal",\\
  "--text-heading-4--fontType": "regular",\\
  "--text-heading-4--fontStyle": "normal",\\
  "--text-heading-4--fontStretch": "normal",\\
  "--text-heading-4--lineHeight": "1.15",\\
  "--text-heading-4--marginLeft": "0px",\\
  "--text-heading-4--color": "var(--palette-color6)",\\
  "--text-heading-4--borderBottomStyle": "none",\\
  "--text-heading-4--textDecoration": "none",\\
  "--text-heading-4--letterSpacing": "0.10",\\
  "--text-heading-4--textTransform": "uppercase",\\
  "--text-heading-4--stroke": "var(--palette-color2)",\\
  "--text-heading-4--textAlign": "left",\\
  "--text-heading-4--justifyContent": "flex-start",\\
  "--text-heading-4--marginTop": "auto",\\
  "--text-heading-4--marginBottom": "0",\\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-5--fontSize--desktop": "40px",\\
  "--text-heading-5--fontSize--tablet": "32px",\\
  "--text-heading-5--fontSize--mobile": "28px",\\
  "--text-heading-5--fontFamily": "var(--font1)",\\
  "--text-heading-5--fontWeight": "normal",\\
  "--text-heading-5--fontType": "regular",\\
  "--text-heading-5--fontStyle": "normal",\\
  "--text-heading-5--fontStretch": "normal",\\
  "--text-heading-5--lineHeight": "1.2",\\
  "--text-heading-5--marginLeft": "0px",\\
  "--text-heading-5--color": "var(--palette-color6)",\\
  "--text-heading-5--borderBottomStyle": "none",\\
  "--text-heading-5--textDecoration": "none",\\
  "--text-heading-5--letterSpacing": "0",\\
  "--text-heading-5--textTransform": "none",\\
  "--text-heading-5--stroke": "var(--palette-color2)",\\
  "--text-heading-5--textAlign": "left",\\
  "--text-heading-5--justifyContent": "flex-start",\\
  "--text-heading-5--marginTop": "auto",\\
  "--text-heading-5--marginBottom": "0",\\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-6--fontSize--desktop": "36px",\\
  "--text-heading-6--fontSize--tablet": "28px",\\
  "--text-heading-6--fontSize--mobile": "24px",\\
  "--text-heading-6--fontFamily": "var(--font2)",\\
  "--text-heading-6--fontWeight": "normal",\\
  "--text-heading-6--fontType": "regular",\\
  "--text-heading-6--fontStyle": "normal",\\
  "--text-heading-6--fontStretch": "normal",\\
  "--text-heading-6--lineHeight": "1.2",\\
  "--text-heading-6--marginLeft": "0px",\\
  "--text-heading-6--color": "var(--palette-color6)",\\
  "--text-heading-6--borderBottomStyle": "none",\\
  "--text-heading-6--textDecoration": "none",\\
  "--text-heading-6--letterSpacing": "0",\\
  "--text-heading-6--textTransform": "none",\\
  "--text-heading-6--stroke": "var(--palette-color2)",\\
  "--text-heading-6--textAlign": "left",\\
  "--text-heading-6--justifyContent": "flex-start",\\
  "--text-heading-6--marginTop": "auto",\\
  "--text-heading-6--marginBottom": "0",\\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-7--fontSize--desktop": "20px",\\
  "--text-heading-7--fontSize--tablet": "20px",\\
  "--text-heading-7--fontSize--mobile": "20px",\\
  "--text-heading-7--fontFamily": "var(--font1)",\\
  "--text-heading-7--fontWeight": "normal",\\
  "--text-heading-7--fontType": "regular",\\
  "--text-heading-7--fontStyle": "normal",\\
  "--text-heading-7--fontStretch": "normal",\\
  "--text-heading-7--lineHeight": "1.35",\\
  "--text-heading-7--marginLeft": "0px",\\
  "--text-heading-7--color": "var(--palette-color5)",\\
  "--text-heading-7--borderBottomStyle": "none",\\
  "--text-heading-7--textDecoration": "none",\\
  "--text-heading-7--letterSpacing": "0",\\
  "--text-heading-7--textTransform": "none",\\
  "--text-heading-7--stroke": "var(--palette-color2)",\\
  "--text-heading-7--textAlign": "left",\\
  "--text-heading-7--justifyContent": "flex-start",\\
  "--text-heading-7--marginTop": "auto",\\
  "--text-heading-7--marginBottom": "0",\\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-8--fontSize--desktop": "72px",\\
  "--text-heading-8--fontSize--tablet": "48px",\\
  "--text-heading-8--fontSize--mobile": "32px",\\
  "--text-heading-8--fontFamily": "var(--font1)",\\
  "--text-heading-8--fontWeight": "normal",\\
  "--text-heading-8--fontType": "regular",\\
  "--text-heading-8--fontStyle": "normal",\\
  "--text-heading-8--fontStretch": "normal",\\
  "--text-heading-8--lineHeight": "1.35",\\
  "--text-heading-8--marginLeft": "0px",\\
  "--text-heading-8--color": "var(--palette-color5)",\\
  "--text-heading-8--borderBottomStyle": "none",\\
  "--text-heading-8--textDecoration": "none",\\
  "--text-heading-8--letterSpacing": "0",\\
  "--text-heading-8--textTransform": "none",\\
  "--text-heading-8--stroke": "var(--palette-color2)",\\
  "--text-heading-8--textAlign": "center",\\
  "--text-heading-8--justifyContent": "flex-start",\\
  "--text-heading-8--marginTop": "auto",\\
  "--text-heading-8--marginBottom": "0",\\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-9--fontSize--desktop": "32px",\\
  "--text-heading-9--fontSize--tablet": "32px",\\
  "--text-heading-9--fontSize--mobile": "32px",\\
  "--text-heading-9--fontFamily": "var(--font1)",\\
  "--text-heading-9--fontWeight": "normal",\\
  "--text-heading-9--fontType": "regular",\\
  "--text-heading-9--fontStyle": "normal",\\
  "--text-heading-9--fontStretch": "normal",\\
  "--text-heading-9--lineHeight": "1.35",\\
  "--text-heading-9--marginLeft": "0px",\\
  "--text-heading-9--color": "var(--palette-color5)",\\
  "--text-heading-9--borderBottomStyle": "none",\\
  "--text-heading-9--textDecoration": "none",\\
  "--text-heading-9--letterSpacing": "0",\\
  "--text-heading-9--textTransform": "none",\\
  "--text-heading-9--stroke": "var(--palette-color2)",\\
  "--text-heading-9--textAlign": "center",\\
  "--text-heading-9--justifyContent": "flex-start",\\
  "--text-heading-9--marginTop": "auto",\\
  "--text-heading-9--marginBottom": "0",\\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-1--fontSize--desktop": "22px",\\
  "--text-body-1--fontSize--tablet": "20px",\\
  "--text-body-1--fontSize--mobile": "18px",\\
  "--text-body-1--fontFamily": "var(--font1)",\\
  "--text-body-1--fontWeight": "normal",\\
  "--text-body-1--fontType": "regular",\\
  "--text-body-1--fontStyle": "normal",\\
  "--text-body-1--fontStretch": "normal",\\
  "--text-body-1--lineHeight": "1.3",\\
  "--text-body-1--marginLeft": "0px",\\
  "--text-body-1--color": "var(--palette-color5)",\\
  "--text-body-1--borderBottomStyle": "none",\\
  "--text-body-1--textDecoration": "none",\\
  "--text-body-1--letterSpacing": "0",\\
  "--text-body-1--textTransform": "none",\\
  "--text-body-1--stroke": "var(--palette-color2)",\\
  "--text-body-1--textAlign": "left",\\
  "--text-body-1--justifyContent": "flex-start",\\
  "--text-body-1--marginTop": "auto",\\
  "--text-body-1--marginBottom": "0",\\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-2--fontSize--desktop": "22px",\\
  "--text-body-2--fontSize--tablet": "20px",\\
  "--text-body-2--fontSize--mobile": "18px",\\
  "--text-body-2--fontFamily": "var(--font2)",\\
  "--text-body-2--fontWeight": "normal",\\
  "--text-body-2--fontType": "regular",\\
  "--text-body-2--fontStyle": "normal",\\
  "--text-body-2--fontStretch": "normal",\\
  "--text-body-2--lineHeight": "1.3",\\
  "--text-body-2--marginLeft": "0px",\\
  "--text-body-2--color": "var(--palette-color4)",\\
  "--text-body-2--borderBottomStyle": "none",\\
  "--text-body-2--textDecoration": "none",\\
  "--text-body-2--letterSpacing": "0.03",\\
  "--text-body-2--textTransform": "none",\\
  "--text-body-2--Stroke": "var(--palette-color2)",\\
  "--text-body-2--textAlign": "left",\\
  "--text-body-2--justifyContent": "flex-start",\\
  "--text-body-2--marginTop": "auto",\\
  "--text-body-2--marginBottom": "0",\\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-3--fontSize--desktop": "18px",\\
  "--text-body-3--fontSize--tablet": "16px",\\
  "--text-body-3--fontSize--mobile": "16px",\\
  "--text-body-3--fontFamily": "var(--font1)",\\
  "--text-body-3--fontWeight": "normal",\\
  "--text-body-3--fontType": "regular",\\
  "--text-body-3--fontStyle": "normal",\\
  "--text-body-3--fontStretch": "normal",\\
  "--text-body-3--lineHeight": "1.35",\\
  "--text-body-3--marginLeft": "0px",\\
  "--text-body-3--color": "var(--palette-color4)",\\
  "--text-body-3--borderBottomStyle": "none",\\
  "--text-body-3--textDecoration": "none",\\
  "--text-body-3--letterSpacing": "0",\\
  "--text-body-3--textTransform": "none",\\
  "--text-body-3--Stroke": "var(--palette-color2)",\\
  "--text-body-3--textAlign": "left",\\
  "--text-body-3--justifyContent": "flex-start",\\
  "--text-body-3--marginTop": "auto",\\
  "--text-body-3--marginBottom": "0",\\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-4--fontSize--desktop": "18px",\\
  "--text-body-4--fontSize--tablet": "16px",\\
  "--text-body-4--fontSize--mobile": "16px",\\
  "--text-body-4--fontFamily": "var(--font2)",\\
  "--text-body-4--fontWeight": "normal",\\
  "--text-body-4--fontType": "regular",\\
  "--text-body-4--fontStyle": "normal",\\
  "--text-body-4--fontStretch": "normal",\\
  "--text-body-4--lineHeight": "1.35",\\
  "--text-body-4--marginLeft": "0px",\\
  "--text-body-4--color": "var(--palette-color4)",\\
  "--text-body-4--borderBottomStyle": "none",\\
  "--text-body-4--textDecoration": "none",\\
  "--text-body-4--letterSpacing": "0",\\
  "--text-body-4--textTransform": "none",\\
  "--text-body-4--Stroke": "var(--palette-color2)",\\
  "--text-body-4--textAlign": "left",\\
  "--text-body-4--justifyContent": "flex-start",\\
  "--text-body-4--marginTop": "auto",\\
  "--text-body-4--marginBottom": "0",\\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-5--fontSize--desktop": "18px",\\
  "--text-body-5--fontSize--tablet": "16px",\\
  "--text-body-5--fontSize--mobile": "16px",\\
  "--text-body-5--fontFamily": "var(--font1)",\\
  "--text-body-5--fontWeight": "normal",\\
  "--text-body-5--fontType": "italic",\\
  "--text-body-5--fontStyle": "normal",\\
  "--text-body-5--fontStretch": "normal",\\
  "--text-body-5--lineHeight": "1.35",\\
  "--text-body-5--marginLeft": "0px",\\
  "--text-body-5--color": "var(--palette-color4)",\\
  "--text-body-5--borderBottomStyle": "none",\\
  "--text-body-5--textDecoration": "none",\\
  "--text-body-5--letterSpacing": "0",\\
  "--text-body-5--textTransform": "none",\\
  "--text-body-5--Stroke": "var(--palette-color2)",\\
  "--text-body-5--textAlign": "center",\\
  "--text-body-5--justifyContent": "flex-start",\\
  "--text-body-5--marginTop": "auto",\\
  "--text-body-5--marginBottom": "0",\\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-6--fontSize--desktop": "16px",\\
  "--text-body-6--fontSize--tablet": "14px",\\
  "--text-body-6--fontSize--mobile": "14px",\\
  "--text-body-6--fontFamily": "var(--font2)",\\
  "--text-body-6--fontWeight": "normal",\\
  "--text-body-6--fontType": "regular",\\
  "--text-body-6--fontStyle": "normal",\\
  "--text-body-6--fontStretch": "normal",\\
  "--text-body-6--lineHeight": "1.35",\\
  "--text-body-6--marginLeft": "0px",\\
  "--text-body-6--color": "var(--palette-color4)",\\
  "--text-body-6--borderBottomStyle": "none",\\
  "--text-body-6--textDecoration": "none",\\
  "--text-body-6--letterSpacing": "0",\\
  "--text-body-6--textTransform": "none",\\
  "--text-body-6--Stroke": "var(--palette-color2)",\\
  "--text-body-6--textAlign": "left",\\
  "--text-body-6--justifyContent": "flex-start",\\
  "--text-body-6--marginTop": "auto",\\
  "--text-body-6--marginBottom": "0",\\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-1--fontSize--desktop": "22px",\\
  "--text-component-1--fontSize--tablet": "20px",\\
  "--text-component-1--fontSize--mobile": "20px",\\
  "--text-component-1--fontFamily": "var(--font1)",\\
  "--text-component-1--fontWeight": "normal",\\
  "--text-component-1--fontType": "regular",\\
  "--text-component-1--fontStyle": "normal",\\
  "--text-component-1--fontStretch": "normal",\\
  "--text-component-1--lineHeight": "1.35",\\
  "--text-component-1--marginLeft": "0px",\\
  "--text-component-1--color": "var(--color6)",\\
  "--text-component-1--borderBottomStyle": "none",\\
  "--text-component-1--textDecoration": "none",\\
  "--text-component-1--letterSpacing": "0",\\
  "--text-component-1--textTransform": "none",\\
  "--text-component-1--stroke": "var(--palette-color2)",\\
  "--text-component-1--textAlign": "left",\\
  "--text-component-1--justifyContent": "flex-start",\\
  "--text-component-1--marginTop": "auto",\\
  "--text-component-1--marginBottom": "0",\\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-2--fontSize--desktop": "24px",\\
  "--text-component-2--fontSize--tablet": "20px",\\
  "--text-component-2--fontSize--mobile": "20px",\\
  "--text-component-2--fontFamily": "var(--font1)",\\
  "--text-component-2--fontWeight": "normal",\\
  "--text-component-2--fontType": "regular",\\
  "--text-component-2--fontStyle": "normal",\\
  "--text-component-2--fontStretch": "normal",\\
  "--text-component-2--lineHeight": "1.35",\\
  "--text-component-2--marginLeft": "0px",\\
  "--text-component-2--color": "var(--palette-color1)",\\
  "--text-component-2--borderBottomStyle": "none",\\
  "--text-component-2--textDecoration": "none",\\
  "--text-component-2--letterSpacing": "0.16",\\
  "--text-component-2--textTransform": "none",\\
  "--text-component-2--stroke": "var(--palette-color2)",\\
  "--text-component-2--textAlign": "left",\\
  "--text-component-2--justifyContent": "flex-start",\\
  "--text-component-2--marginTop": "auto",\\
  "--text-component-2--marginBottom": "0",\\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-3--fontSize--desktop": "14px",\\
  "--text-component-3--fontSize--tablet": "14px",\\
  "--text-component-3--fontSize--mobile": "14px",\\
  "--text-component-3--fontFamily": "var(--font1)",\\
  "--text-component-3--fontWeight": "normal",\\
  "--text-component-3--fontType": "regular",\\
  "--text-component-3--fontStyle": "normal",\\
  "--text-component-3--fontStretch": "normal",\\
  "--text-component-3--lineHeight": "1.35",\\
  "--text-component-3--marginLeft": "0px",\\
  "--text-component-3--color": "var(--palette-color6)",\\
  "--text-component-3--borderBottomStyle": "none",\\
  "--text-component-3--textDecoration": "none",\\
  "--text-component-3--letterSpacing": "0.2",\\
  "--text-component-3--textTransform": "uppercase",\\
  "--text-component-3--stroke": "var(--palette-color2)",\\
  "--text-component-3--textAlign": "center",\\
  "--text-component-3--justifyContent": "flex-start",\\
  "--text-component-3--marginTop": "auto",\\
  "--text-component-3--marginBottom": "0",\\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-4--fontSize--desktop": "22px",\\
  "--text-component-4--fontSize--tablet": "20px",\\
  "--text-component-4--fontSize--mobile": "20px",\\
  "--text-component-4--fontFamily": "var(--font1)",\\
  "--text-component-4--fontWeight": "normal",\\
  "--text-component-4--fontType": "regular",\\
  "--text-component-4--fontStyle": "normal",\\
  "--text-component-4--fontStretch": "normal",\\
  "--text-component-4--lineHeight": "1.35",\\
  "--text-component-4--marginLeft": "0px",\\
  "--text-component-4--color": "var(--color6)",\\
  "--text-component-4--borderBottomStyle": "none",\\
  "--text-component-4--textDecoration": "none",\\
  "--text-component-4--letterSpacing": "0.02",\\
  "--text-component-4--textTransform": "none",\\
  "--text-component-4--stroke": "var(--palette-color2)",\\
  "--text-component-4--textAlign": "left",\\
  "--text-component-4--justifyContent": "flex-start",\\
  "--text-component-4--marginTop": "auto",\\
  "--text-component-4--marginBottom": "0",\\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-1--fontSize--desktop": "36px",\\
  "--text-subheading-1--fontSize--tablet": "32px",\\
  "--text-subheading-1--fontSize--mobile": "28px",\\
  "--text-subheading-1--fontFamily": "var(--font2)",\\
  "--text-subheading-1--fontWeight": "normal",\\
  "--text-subheading-1--fontType": "regular",\\
  "--text-subheading-1--fontStyle": "normal",\\
  "--text-subheading-1--fontStretch": "normal",\\
  "--text-subheading-1--lineHeight": "1.1",\\
  "--text-subheading-1--marginLeft": "0px",\\
  "--text-subheading-1--color": "var(--palette-color6)",\\
  "--text-subheading-1--borderBottomStyle": "none",\\
  "--text-subheading-1--textDecoration": "none",\\
  "--text-subheading-1--letterSpacing": "0.05",\\
  "--text-subheading-1--textTransform": "uppercase",\\
  "--text-subheading-1--stroke": "var(--palette-color2)",\\
  "--text-subheading-1--textAlign": "left",\\
  "--text-subheading-1--justifyContent": "flex-start",\\
  "--text-subheading-1--marginTop": "auto",\\
  "--text-subheading-1--marginBottom": "0",\\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-2--fontSize--desktop": "28px",\\
  "--text-subheading-2--fontSize--tablet": "24px",\\
  "--text-subheading-2--fontSize--mobile": "20px",\\
  "--text-subheading-2--fontFamily": "var(--font2)",\\
  "--text-subheading-2--fontWeight": "normal",\\
  "--text-subheading-2--fontType": "bold",\\
  "--text-subheading-2--fontStyle": "normal",\\
  "--text-subheading-2--fontStretch": "normal",\\
  "--text-subheading-2--lineHeight": "1.15",\\
  "--text-subheading-2--marginLeft": "0px",\\
  "--text-subheading-2--color": "var(--palette-color6)",\\
  "--text-subheading-2--borderBottomStyle": "none",\\
  "--text-subheading-2--textDecoration": "none",\\
  "--text-subheading-2--letterSpacing": "0.05",\\
  "--text-subheading-2--textTransform": "none",\\
  "--text-subheading-2--stroke": "var(--palette-color2)",\\
  "--text-subheading-2--textAlign": "left",\\
  "--text-subheading-2--justifyContent": "flex-start",\\
  "--text-subheading-2--marginTop": "auto",\\
  "--text-subheading-2--marginBottom": "0",\\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-3--fontSize--desktop": "26px",\\
  "--text-subheading-3--fontSize--tablet": "22px",\\
  "--text-subheading-3--fontSize--mobile": "18px",\\
  "--text-subheading-3--fontFamily": "var(--font2)",\\
  "--text-subheading-3--fontWeight": "normal",\\
  "--text-subheading-3--fontType": "regular",\\
  "--text-subheading-3--fontStyle": "normal",\\
  "--text-subheading-3--fontStretch": "normal",\\
  "--text-subheading-3--lineHeight": "1.15",\\
  "--text-subheading-3--marginLeft": "0px",\\
  "--text-subheading-3--color": "var(--palette-color6)",\\
  "--text-subheading-3--borderBottomStyle": "none",\\
  "--text-subheading-3--textDecoration": "none",\\
  "--text-subheading-3--letterSpacing": "0",\\
  "--text-subheading-3--textTransform": "none",\\
  "--text-subheading-3--stroke": "var(--palette-color2)",\\
  "--text-subheading-3--textAlign": "center",\\
  "--text-subheading-3--justifyContent": "flex-start",\\
  "--text-subheading-3--marginTop": "auto",\\
  "--text-subheading-3--marginBottom": "0",\\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-4--fontSize--desktop": "24px",\\
  "--text-subheading-4--fontSize--tablet": "20px",\\
  "--text-subheading-4--fontSize--mobile": "16px",\\
  "--text-subheading-4--fontFamily": "var(--font2)",\\
  "--text-subheading-4--fontWeight": "normal",\\
  "--text-subheading-4--fontType": "bold",\\
  "--text-subheading-4--fontStyle": "normal",\\
  "--text-subheading-4--fontStretch": "normal",\\
  "--text-subheading-4--lineHeight": "1.15",\\
  "--text-subheading-4--marginLeft": "0px",\\
  "--text-subheading-4--color": "var(--palette-color0)",\\
  "--text-subheading-4--borderBottomStyle": "none",\\
  "--text-subheading-4--textDecoration": "none",\\
  "--text-subheading-4--letterSpacing": "0.05",\\
  "--text-subheading-4--textTransform": "none",\\
  "--text-subheading-4--stroke": "var(--palette-color2)",\\
  "--text-subheading-4--textAlign": "left",\\
  "--text-subheading-4--justifyContent": "flex-start",\\
  "--text-subheading-4--marginTop": "auto",\\
  "--text-subheading-4--marginBottom": "0",\\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-5--fontSize--desktop": "24px",\\
  "--text-subheading-5--fontSize--tablet": "20px",\\
  "--text-subheading-5--fontSize--mobile": "16px",\\
  "--text-subheading-5--fontFamily": "var(--font1)",\\
  "--text-subheading-5--fontWeight": "normal",\\
  "--text-subheading-5--fontType": "bold",\\
  "--text-subheading-5--fontStyle": "normal",\\
  "--text-subheading-5--fontStretch": "normal",\\
  "--text-subheading-5--lineHeight": "1.15",\\
  "--text-subheading-5--marginLeft": "0px",\\
  "--text-subheading-5--color": "var(--palette-color5)",\\
  "--text-subheading-5--borderBottomStyle": "none",\\
  "--text-subheading-5--textDecoration": "none",\\
  "--text-subheading-5--letterSpacing": "-0.05",\\
  "--text-subheading-5--textTransform": "none",\\
  "--text-subheading-5--stroke": "var(--palette-color2)",\\
  "--text-subheading-5--textAlign": "left",\\
  "--text-subheading-5--justifyContent": "flex-start",\\
  "--text-subheading-5--marginTop": "auto",\\
  "--text-subheading-5--marginBottom": "0",\\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-6--fontSize--desktop": "18px",\\
  "--text-subheading-6--fontSize--tablet": "16px",\\
  "--text-subheading-6--fontSize--mobile": "14px",\\
  "--text-subheading-6--fontFamily": "var(--font2)",\\
  "--text-subheading-6--fontWeight": "normal",\\
  "--text-subheading-6--fontType": "bold",\\
  "--text-subheading-6--fontStyle": "normal",\\
  "--text-subheading-6--fontStretch": "normal",\\
  "--text-subheading-6--lineHeight": "1.25",\\
  "--text-subheading-6--marginLeft": "0px",\\
  "--text-subheading-6--color": "var(--palette-color5)",\\
  "--text-subheading-6--borderBottomStyle": "none",\\
  "--text-subheading-6--textDecoration": "none",\\
  "--text-subheading-6--letterSpacing": "0",\\
  "--text-subheading-6--textTransform": "none",\\
  "--text-subheading-6--stroke": "var(--palette-color2)",\\
  "--text-subheading-6--textAlign": "left",\\
  "--text-subheading-6--justifyContent": "flex-start",\\
  "--text-subheading-6--marginTop": "auto",\\
  "--text-subheading-6--marginBottom": "0",\\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-1--fontSize--desktop": "20px",\\
  "--text-detail-1--fontSize--tablet": "18px",\\
  "--text-detail-1--fontSize--mobile": "16px",\\
  "--text-detail-1--fontFamily": "var(--font2)",\\
  "--text-detail-1--fontWeight": "normal",\\
  "--text-detail-1--fontType": "regular",\\
  "--text-detail-1--fontStyle": "normal",\\
  "--text-detail-1--fontStretch": "normal",\\
  "--text-detail-1--lineHeight": "1.2",\\
  "--text-detail-1--marginLeft": "0px",\\
  "--text-detail-1--color": "var(--palette-color6)",\\
  "--text-detail-1--borderBottomStyle": "none",\\
  "--text-detail-1--textDecoration": "none",\\
  "--text-detail-1--letterSpacing": "0",\\
  "--text-detail-1--textTransform": "uppercase",\\
  "--text-detail-1--stroke": "var(--palette-color5)",\\
  "--text-detail-1--textAlign": "left",\\
  "--text-detail-1--justifyContent": "flex-start",\\
  "--text-detail-1--marginTop": "auto",\\
  "--text-detail-1--marginBottom": "0",\\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-2--fontSize--desktop": "16px",\\
  "--text-detail-2--fontSize--tablet": "14px",\\
  "--text-detail-2--fontSize--mobile": "12px",\\
  "--text-detail-2--fontFamily": "var(--font2)",\\
  "--text-detail-2--fontWeight": "normal",\\
  "--text-detail-2--fontType": "bold",\\
  "--text-detail-2--fontStyle": "normal",\\
  "--text-detail-2--fontStretch": "normal",\\
  "--text-detail-2--lineHeight": "1.3",\\
  "--text-detail-2--marginLeft": "0px",\\
  "--text-detail-2--color": "var(--palette-color6)",\\
  "--text-detail-2--borderBottomStyle": "none",\\
  "--text-detail-2--textDecoration": "none",\\
  "--text-detail-2--letterSpacing": "0",\\
  "--text-detail-2--textTransform": "uppercase",\\
  "--text-detail-2--stroke": "var(--palette-color2)",\\
  "--text-detail-2--textAlign": "left",\\
  "--text-detail-2--justifyContent": "flex-start",\\
  "--text-detail-2--marginTop": "auto",\\
  "--text-detail-2--marginBottom": "0",\\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-3--fontSize--desktop": "16px",\\
  "--text-detail-3--fontSize--tablet": "14px",\\
  "--text-detail-3--fontSize--mobile": "12px",\\
  "--text-detail-3--fontFamily": "var(--font2)",\\
  "--text-detail-3--fontWeight": "normal",\\
  "--text-detail-3--fontType": "regular",\\
  "--text-detail-3--fontStyle": "normal",\\
  "--text-detail-3--fontStretch": "normal",\\
  "--text-detail-3--lineHeight": "1.35",\\
  "--text-detail-3--marginLeft": "0px",\\
  "--text-detail-3--color": "var(--palette-color4)",\\
  "--text-detail-3--borderBottomStyle": "none",\\
  "--text-detail-3--textDecoration": "none",\\
  "--text-detail-3--letterSpacing": "0.2",\\
  "--text-detail-3--textTransform": "uppercase",\\
  "--text-detail-3--stroke": "var(--palette-color2)",\\
  "--text-detail-3--textAlign": "left",\\
  "--text-detail-3--justifyContent": "flex-start",\\
  "--text-detail-3--marginTop": "auto",\\
  "--text-detail-3--marginBottom": "0",\\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-4--fontSize--desktop": "22px",\\
  "--text-detail-4--fontSize--tablet": "20px",\\
  "--text-detail-4--fontSize--mobile": "20px",\\
  "--text-detail-4--fontFamily": "var(--font1)",\\
  "--text-detail-4--fontWeight": "normal",\\
  "--text-detail-4--fontType": "regular",\\
  "--text-detail-4--fontStyle": "normal",\\
  "--text-detail-4--fontStretch": "normal",\\
  "--text-detail-4--lineHeight": "1.35",\\
  "--text-detail-4--marginLeft": "0px",\\
  "--text-detail-4--color": "var(--palette-color5)",\\
  "--text-detail-4--borderBottomStyle": "none",\\
  "--text-detail-4--textDecoration": "none",\\
  "--text-detail-4--letterSpacing": "0",\\
  "--text-detail-4--textTransform": "none",\\
  "--text-detail-4--stroke": "var(--palette-color2)",\\
  "--text-detail-4--textAlign": "center",\\
  "--text-detail-4--justifyContent": "flex-start",\\
  "--text-detail-4--marginTop": "auto",\\
  "--text-detail-4--marginBottom": "0",\\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-1--fontSize--desktop": "36px",\\
  "--text-variable-1--fontSize--tablet": "32px",\\
  "--text-variable-1--fontSize--mobile": "30px",\\
  "--text-variable-1--fontFamily": "var(--font2)",\\
  "--text-variable-1--fontWeight": "normal",\\
  "--text-variable-1--fontType": "bold",\\
  "--text-variable-1--fontStyle": "normal",\\
  "--text-variable-1--fontStretch": "normal",\\
  "--text-variable-1--lineHeight": "1.2",\\
  "--text-variable-1--marginLeft": "0px",\\
  "--text-variable-1--color": "var(--palette-color7)",\\
  "--text-variable-1--borderBottomStyle": "none",\\
  "--text-variable-1--textDecoration": "none",\\
  "--text-variable-1--letterSpacing": "0.02",\\
  "--text-variable-1--textTransform": "none",\\
  "--text-variable-1--stroke": "var(--palette-color2)",\\
  "--text-variable-1--textAlign": "left",\\
  "--text-variable-1--justifyContent": "flex-start",\\
  "--text-variable-1--marginTop": "auto",\\
  "--text-variable-1--marginBottom": "0",\\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-2--fontSize--desktop": "24px",\\
  "--text-variable-2--fontSize--tablet": "22px",\\
  "--text-variable-2--fontSize--mobile": "20px",\\
  "--text-variable-2--fontFamily": "var(--font2)",\\
  "--text-variable-2--fontWeight": "normal",\\
  "--text-variable-2--fontType": "bold",\\
  "--text-variable-2--fontStyle": "normal",\\
  "--text-variable-2--fontStretch": "normal",\\
  "--text-variable-2--lineHeight": "1.15",\\
  "--text-variable-2--marginLeft": "0px",\\
  "--text-variable-2--color": "var(--palette-color6)",\\
  "--text-variable-2--borderBottomStyle": "none",\\
  "--text-variable-2--textDecoration": "none",\\
  "--text-variable-2--letterSpacing": "0",\\
  "--text-variable-2--textTransform": "none",\\
  "--text-variable-2--stroke": "var(--palette-color2)",\\
  "--text-variable-2--textAlign": "left",\\
  "--text-variable-2--justifyContent": "flex-start",\\
  "--text-variable-2--marginTop": "auto",\\
  "--text-variable-2--marginBottom": "0",\\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-3--fontSize--desktop": "20px",\\
  "--text-variable-3--fontSize--tablet": "18px",\\
  "--text-variable-3--fontSize--mobile": "16px",\\
  "--text-variable-3--fontFamily": "var(--font1)",\\
  "--text-variable-3--fontWeight": "normal",\\
  "--text-variable-3--fontType": "bold",\\
  "--text-variable-3--fontStyle": "normal",\\
  "--text-variable-3--fontStretch": "normal",\\
  "--text-variable-3--lineHeight": "1.2",\\
  "--text-variable-3--marginLeft": "0px",\\
  "--text-variable-3--color": "var(--palette-color6)",\\
  "--text-variable-3--borderBottomStyle": "none",\\
  "--text-variable-3--textDecoration": "none",\\
  "--text-variable-3--letterSpacing": "0",\\
  "--text-variable-3--textTransform": "none",\\
  "--text-variable-3--stroke": "var(--palette-color2)",\\
  "--text-variable-3--textAlign": "left",\\
  "--text-variable-3--justifyContent": "flex-start",\\
  "--text-variable-3--marginTop": "auto",\\
  "--text-variable-3--marginBottom": "0",\\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-4--fontSize--desktop": "16px",\\
  "--text-variable-4--fontSize--tablet": "14px",\\
  "--text-variable-4--fontSize--mobile": "12px",\\
  "--text-variable-4--fontFamily": "var(--font2)",\\
  "--text-variable-4--fontWeight": "normal",\\
  "--text-variable-4--fontType": "bold",\\
  "--text-variable-4--fontStyle": "normal",\\
  "--text-variable-4--fontStretch": "normal",\\
  "--text-variable-4--lineHeight": "1.3",\\
  "--text-variable-4--marginLeft": "0px",\\
  "--text-variable-4--color": "var(--palette-color6)",\\
  "--text-variable-4--borderBottomStyle": "none",\\
  "--text-variable-4--textDecoration": "none",\\
  "--text-variable-4--letterSpacing": "0.02",\\
  "--text-variable-4--textTransform": "none",\\
  "--text-variable-4--stroke": "var(--palette-color2)",\\
  "--text-variable-4--textAlign": "left",\\
  "--text-variable-4--justifyContent": "flex-start",\\
  "--text-variable-4--marginTop": "auto",\\
  "--text-variable-4--marginBottom": "0",\\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-1--fontSize--desktop": "48px",\\
  "--text-question-1--fontSize--tablet": "20px",\\
  "--text-question-1--fontSize--mobile": "20px",\\
  "--text-question-1--fontFamily": "var(--font1)",\\
  "--text-question-1--fontWeight": "normal",\\
  "--text-question-1--fontType": "regular",\\
  "--text-question-1--fontStyle": "normal",\\
  "--text-question-1--fontStretch": "normal",\\
  "--text-question-1--lineHeight": "1.35",\\
  "--text-question-1--marginLeft": "0px",\\
  "--text-question-1--color": "var(--palette-color5)",\\
  "--text-question-1--borderBottomStyle": "none",\\
  "--text-question-1--textDecoration": "none",\\
  "--text-question-1--letterSpacing": "0",\\
  "--text-question-1--textTransform": "none",\\
  "--text-question-1--stroke": "var(--palette-color2)",\\
  "--text-question-1--textAlign": "left",\\
  "--text-question-1--justifyContent": "flex-start",\\
  "--text-question-1--marginTop": "auto",\\
  "--text-question-1--marginBottom": "0",\\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-2--fontSize--desktop": "24px",\\
  "--text-question-2--fontSize--tablet": "20px",\\
  "--text-question-2--fontSize--mobile": "20px",\\
  "--text-question-2--fontFamily": "var(--font1)",\\
  "--text-question-2--fontWeight": "normal",\\
  "--text-question-2--fontType": "bold",\\
  "--text-question-2--fontStyle": "normal",\\
  "--text-question-2--fontStretch": "normal",\\
  "--text-question-2--lineHeight": "1.35",\\
  "--text-question-2--marginLeft": "0px",\\
  "--text-question-2--color": "var(--palette-color5)",\\
  "--text-question-2--borderBottomStyle": "none",\\
  "--text-question-2--textDecoration": "none",\\
  "--text-question-2--letterSpacing": "0",\\
  "--text-question-2--textTransform": "none",\\
  "--text-question-2--stroke": "var(--palette-color2)",\\
  "--text-question-2--textAlign": "left",\\
  "--text-question-2--justifyContent": "flex-start",\\
  "--text-question-2--marginTop": "auto",\\
  "--text-question-2--marginBottom": "0",\\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-1--fontSize--desktop": "16px",\\
  "--text-button-1--fontSize--tablet": "16px",\\
  "--text-button-1--fontSize--mobile": "16px",\\
  "--text-button-1--fontFamily": "var(--font2)",\\
  "--text-button-1--fontWeight": "normal",\\
  "--text-button-1--fontType": "regular",\\
  "--text-button-1--fontStyle": "normal",\\
  "--text-button-1--fontStretch": "normal",\\
  "--text-button-1--lineHeight": "1.25",\\
  "--text-button-1--marginLeft": "0px",\\
  "--text-button-1--color": "var(--palette-color7)",\\
  "--text-button-1--borderBottomStyle": "none",\\
  "--text-button-1--textDecoration": "none",\\
  "--text-button-1--letterSpacing": "0.12",\\
  "--text-button-1--textTransform": "uppercase",\\
  "--text-button-1--stroke": "var(--palette-color2)",\\
  "--text-button-1--textAlign": "center",\\
  "--text-button-1--justifyContent": "flex-start",\\
  "--text-button-1--marginTop": "auto",\\
  "--text-button-1--marginBottom": "0",\\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-2--fontSize--desktop": "16px",\\
  "--text-button-2--fontSize--tablet": "16px",\\
  "--text-button-2--fontSize--mobile": "16px",\\
  "--text-button-2--fontFamily": "var(--font2)",\\
  "--text-button-2--fontWeight": "normal",\\
  "--text-button-2--fontType": "regular",\\
  "--text-button-2--fontStyle": "normal",\\
  "--text-button-2--fontStretch": "normal",\\
  "--text-button-2--lineHeight": "1.25",\\
  "--text-button-2--marginLeft": "0px",\\
  "--text-button-2--color": "var(--palette-color0)",\\
  "--text-button-2--borderBottomStyle": "none",\\
  "--text-button-2--textDecoration": "none",\\
  "--text-button-2--letterSpacing": "0.12",\\
  "--text-button-2--textTransform": "uppercase",\\
  "--text-button-2--stroke": "var(--palette-color2)",\\
  "--text-button-2--textAlign": "center",\\
  "--text-button-2--justifyContent": "flex-start",\\
  "--text-button-2--marginTop": "auto",\\
  "--text-button-2--marginBottom": "0",\\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-3--fontSize--desktop": "16px",\\
  "--text-button-3--fontSize--tablet": "16px",\\
  "--text-button-3--fontSize--mobile": "16px",\\
  "--text-button-3--fontFamily": "var(--font2)",\\
  "--text-button-3--fontWeight": "normal",\\
  "--text-button-3--fontType": "regular",\\
  "--text-button-3--fontStyle": "normal",\\
  "--text-button-3--fontStretch": "normal",\\
  "--text-button-3--lineHeight": "1.25",\\
  "--text-button-3--marginLeft": "0px",\\
  "--text-button-3--color": "var(--palette-color5)",\\
  "--text-button-3--borderBottomStyle": "none",\\
  "--text-button-3--textDecoration": "none",\\
  "--text-button-3--letterSpacing": "0.12",\\
  "--text-button-3--textTransform": "uppercase",\\
  "--text-button-3--stroke": "var(--palette-color2)",\\
  "--text-button-3--textAlign": "center",\\
  "--text-button-3--justifyContent": "flex-start",\\
  "--text-button-3--marginTop": "auto",\\
  "--text-button-3--marginBottom": "0",\\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-4--fontSize--desktop": "16px",\\
  "--text-button-4--fontSize--tablet": "16px",\\
  "--text-button-4--fontSize--mobile": "16px",\\
  "--text-button-4--fontFamily": "var(--font2)",\\
  "--text-button-4--fontWeight": "normal",\\
  "--text-button-4--fontType": "regular",\\
  "--text-button-4--fontStyle": "normal",\\
  "--text-button-4--fontStretch": "normal",\\
  "--text-button-4--lineHeight": "1.25",\\
  "--text-button-4--marginLeft": "0px",\\
  "--text-button-4--color": "var(--palette-color4)",\\
  "--text-button-4--borderBottomStyle": "none",\\
  "--text-button-4--textDecoration": "none",\\
  "--text-button-4--letterSpacing": "0.12",\\
  "--text-button-4--textTransform": "uppercase",\\
  "--text-button-4--stroke": "var(--palette-color2)",\\
  "--text-button-4--textAlign": "center",\\
  "--text-button-4--justifyContent": "flex-start",\\
  "--text-button-4--marginTop": "auto",\\
  "--text-button-4--marginBottom": "0",\\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-1--fontSize--desktop": "18px",\\
  "--text-uic-1--fontSize--tablet": "18px",\\
  "--text-uic-1--fontSize--mobile": "18px",\\
  "--text-uic-1--fontFamily": "var(--font1)",\\
  "--text-uic-1--fontWeight": "normal",\\
  "--text-uic-1--fontType": "italic",\\
  "--text-uic-1--fontStyle": "normal",\\
  "--text-uic-1--fontStretch": "normal",\\
  "--text-uic-1--lineHeight": "1.35",\\
  "--text-uic-1--marginLeft": "0px",\\
  "--text-uic-1--color": "var(--palette-color4)",\\
  "--text-uic-1--borderBottomStyle": "none",\\
  "--text-uic-1--textDecoration": "none",\\
  "--text-uic-1--letterSpacing": "0",\\
  "--text-uic-1--textTransform": "none",\\
  "--text-uic-1--stroke": "var(--palette-color2)",\\
  "--text-uic-1--textAlign": "left",\\
  "--text-uic-1--justifyContent": "flex-start",\\
  "--text-uic-1--marginTop": "auto",\\
  "--text-uic-1--marginBottom": "0",\\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-2--fontSize--desktop": "18px",\\
  "--text-uic-2--fontSize--tablet": "18px",\\
  "--text-uic-2--fontSize--mobile": "18px",\\
  "--text-uic-2--fontFamily": "var(--font1)",\\
  "--text-uic-2--fontWeight": "normal",\\
  "--text-uic-2--fontType": "italic",\\
  "--text-uic-2--fontStyle": "normal",\\
  "--text-uic-2--fontStretch": "normal",\\
  "--text-uic-2--lineHeight": "1.35",\\
  "--text-uic-2--marginLeft": "0px",\\
  "--text-uic-2--color": "var(--palette-color1)",\\
  "--text-uic-2--borderBottomStyle": "none",\\
  "--text-uic-2--textDecoration": "none",\\
  "--text-uic-2--letterSpacing": "0",\\
  "--text-uic-2--textTransform": "none",\\
  "--text-uic-2--stroke": "var(--palette-color2)",\\
  "--text-uic-2--textAlign": "left",\\
  "--text-uic-2--justifyContent": "flex-start",\\
  "--text-uic-2--marginTop": "auto",\\
  "--text-uic-2--marginBottom": "0",\\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-3--fontSize--desktop": "22px",\\
  "--text-uic-3--fontSize--tablet": "22px",\\
  "--text-uic-3--fontSize--mobile": "22px",\\
  "--text-uic-3--fontFamily": "var(--font1)",\\
  "--text-uic-3--fontWeight": "normal",\\
  "--text-uic-3--fontType": "regular",\\
  "--text-uic-3--fontStyle": "normal",\\
  "--text-uic-3--fontStretch": "normal",\\
  "--text-uic-3--lineHeight": "1.25",\\
  "--text-uic-3--marginLeft": "0px",\\
  "--text-uic-3--color": "var(--palette-color5)",\\
  "--text-uic-3--borderBottomStyle": "none",\\
  "--text-uic-3--textDecoration": "none",\\
  "--text-uic-3--letterSpacing": "0",\\
  "--text-uic-3--textTransform": "none",\\
  "--text-uic-3--stroke": "var(--palette-color2)",\\
  "--text-uic-3--textAlign": "left",\\
  "--text-uic-3--justifyContent": "flex-start",\\
  "--text-uic-3--marginTop": "auto",\\
  "--text-uic-3--marginBottom": "0",\\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-4--fontSize--desktop": "22px",\\
  "--text-uic-4--fontSize--tablet": "22px",\\
  "--text-uic-4--fontSize--mobile": "22px",\\
  "--text-uic-4--fontFamily": "var(--font1)",\\
  "--text-uic-4--fontWeight": "normal",\\
  "--text-uic-4--fontType": "regular",\\
  "--text-uic-4--fontStyle": "normal",\\
  "--text-uic-4--fontStretch": "normal",\\
  "--text-uic-4--lineHeight": "1.25",\\
  "--text-uic-4--marginLeft": "0px",\\
  "--text-uic-4--color": "var(--palette-color4)",\\
  "--text-uic-4--borderBottomStyle": "none",\\
  "--text-uic-4--textDecoration": "none",\\
  "--text-uic-4--letterSpacing": "0",\\
  "--text-uic-4--textTransform": "none",\\
  "--text-uic-4--stroke": "var(--palette-color2)",\\
  "--text-uic-4--textAlign": "left",\\
  "--text-uic-4--justifyContent": "flex-start",\\
  "--text-uic-4--marginTop": "auto",\\
  "--text-uic-4--marginBottom": "0",\\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-5--fontSize--desktop": "22px",\\
  "--text-uic-5--fontSize--tablet": "22px",\\
  "--text-uic-5--fontSize--mobile": "22px",\\
  "--text-uic-5--fontFamily": "var(--font1)",\\
  "--text-uic-5--fontWeight": "normal",\\
  "--text-uic-5--fontType": "regular",\\
  "--text-uic-5--fontStyle": "normal",\\
  "--text-uic-5--fontStretch": "normal",\\
  "--text-uic-5--lineHeight": "1.25",\\
  "--text-uic-5--marginLeft": "0px",\\
  "--text-uic-5--color": "var(--palette-color3)",\\
  "--text-uic-5--borderBottomStyle": "none",\\
  "--text-uic-5--textDecoration": "none",\\
  "--text-uic-5--letterSpacing": "0",\\
  "--text-uic-5--textTransform": "none",\\
  "--text-uic-5--stroke": "var(--palette-color2)",\\
  "--text-uic-5--textAlign": "left",\\
  "--text-uic-5--justifyContent": "flex-start",\\
  "--text-uic-5--marginTop": "auto",\\
  "--text-uic-5--marginBottom": "0",\\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-6--fontSize--desktop": "16px",\\
  "--text-uic-6--fontSize--tablet": "16px",\\
  "--text-uic-6--fontSize--mobile": "16px",\\
  "--text-uic-6--fontFamily": "var(--font2)",\\
  "--text-uic-6--fontWeight": "normal",\\
  "--text-uic-6--fontType": "bold",\\
  "--text-uic-6--fontStyle": "normal",\\
  "--text-uic-6--fontStretch": "normal",\\
  "--text-uic-6--lineHeight": "1.5",\\
  "--text-uic-6--marginLeft": "0px",\\
  "--text-uic-6--color": "var(--palette-color7)",\\
  "--text-uic-6--borderBottomStyle": "none",\\
  "--text-uic-6--textDecoration": "none",\\
  "--text-uic-6--letterSpacing": "0.12",\\
  "--text-uic-6--textTransform": "none",\\
  "--text-uic-6--stroke": "var(--palette-color2)",\\
  "--text-uic-6--textAlign": "left",\\
  "--text-uic-6--justifyContent": "flex-start",\\
  "--text-uic-6--marginTop": "auto",\\
  "--text-uic-6--marginBottom": "0",\\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-closedcaptions--fontSize--desktop": "24px",\\
  "--text-closedcaptions--fontSize--tablet": "24px",\\
  "--text-closedcaptions--fontSize--mobile": "24px",\\
  "--text-closedcaptions--fontFamily": "var(--font1)",\\
  "--text-closedcaptions--fontWeight": "normal",\\
  "--text-closedcaptions--fontType": "regular",\\
  "--text-closedcaptions--fontStyle": "normal",\\
  "--text-closedcaptions--fontStretch": "normal",\\
  "--text-closedcaptions--lineHeight": "1.35",\\
  "--text-closedcaptions--marginLeft": "0px",\\
  "--text-closedcaptions--color": "var(--white)",\\
  "--text-closedcaptions--borderBottomStyle": "none",\\
  "--text-closedcaptions--textDecoration": "none",\\
  "--text-closedcaptions--letterSpacing": "0",\\
  "--text-closedcaptions--textTransform": "none",\\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\\
  "--text-closedcaptions--textAlign": "center",\\
  "--text-closedcaptions--justifyContent": "flex-start",\\
  "--text-closedcaptions--marginTop": "auto",\\
  "--text-closedcaptions--marginBottom": "0",\\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption--fontSize--desktop": "24px",\\
  "--text-caption--fontSize--tablet": "24px",\\
  "--text-caption--fontSize--mobile": "24px",\\
  "--text-caption--fontFamily": "var(--font1)",\\
  "--text-caption--fontWeight": "normal",\\
  "--text-caption--fontType": "regular",\\
  "--text-caption--fontStyle": "normal",\\
  "--text-caption--fontStretch": "normal",\\
  "--text-caption--lineHeight": "1.35",\\
  "--text-caption--marginLeft": "0px",\\
  "--text-caption--color": "var(--palette-color6)",\\
  "--text-caption--borderBottomStyle": "none",\\
  "--text-caption--textDecoration": "none",\\
  "--text-caption--letterSpacing": "0",\\
  "--text-caption--textTransform": "none",\\
  "--text-caption--stroke": "var(--palette-color2)",\\
  "--text-caption--textAlign": "center",\\
  "--text-caption--justifyContent": "flex-start",\\
  "--text-caption--marginTop": "auto",\\
  "--text-caption--marginBottom": "0",\\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_correct--fontSize--desktop": "24px",\\
  "--text-caption_correct--fontSize--tablet": "24px",\\
  "--text-caption_correct--fontSize--mobile": "24px",\\
  "--text-caption_correct--fontFamily": "var(--font1)",\\
  "--text-caption_correct--fontWeight": "normal",\\
  "--text-caption_correct--fontType": "regular",\\
  "--text-caption_correct--fontStyle": "normal",\\
  "--text-caption_correct--fontStretch": "normal",\\
  "--text-caption_correct--lineHeight": "1.35",\\
  "--text-caption_correct--marginLeft": "0px",\\
  "--text-caption_correct--color": "var(--palette-color6)",\\
  "--text-caption_correct--borderBottomStyle": "none",\\
  "--text-caption_correct--textDecoration": "none",\\
  "--text-caption_correct--letterSpacing": "0",\\
  "--text-caption_correct--textTransform": "none",\\
  "--text-caption_correct--stroke": "var(--palette-color2)",\\
  "--text-caption_correct--textAlign": "center",\\
  "--text-caption_correct--justifyContent": "flex-start",\\
  "--text-caption_correct--marginTop": "auto",\\
  "--text-caption_correct--marginBottom": "0",\\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incorrect--fontSize--desktop": "24px",\\
  "--text-caption_incorrect--fontSize--tablet": "24px",\\
  "--text-caption_incorrect--fontSize--mobile": "24px",\\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\\
  "--text-caption_incorrect--fontWeight": "normal",\\
  "--text-caption_incorrect--fontType": "regular",\\
  "--text-caption_incorrect--fontStyle": "normal",\\
  "--text-caption_incorrect--fontStretch": "normal",\\
  "--text-caption_incorrect--lineHeight": "1.35",\\
  "--text-caption_incorrect--marginLeft": "0px",\\
  "--text-caption_incorrect--color": "var(--palette-color6)",\\
  "--text-caption_incorrect--borderBottomStyle": "none",\\
  "--text-caption_incorrect--textDecoration": "none",\\
  "--text-caption_incorrect--letterSpacing": "0",\\
  "--text-caption_incorrect--textTransform": "none",\\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\\
  "--text-caption_incorrect--textAlign": "center",\\
  "--text-caption_incorrect--justifyContent": "flex-start",\\
  "--text-caption_incorrect--marginTop": "auto",\\
  "--text-caption_incorrect--marginBottom": "0",\\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incomplete--fontSize--desktop": "24px",\\
  "--text-caption_incomplete--fontSize--tablet": "24px",\\
  "--text-caption_incomplete--fontSize--mobile": "24px",\\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\\
  "--text-caption_incomplete--fontWeight": "normal",\\
  "--text-caption_incomplete--fontType": "regular",\\
  "--text-caption_incomplete--fontStyle": "normal",\\
  "--text-caption_incomplete--fontStretch": "normal",\\
  "--text-caption_incomplete--lineHeight": "1.35",\\
  "--text-caption_incomplete--marginLeft": "0px",\\
  "--text-caption_incomplete--color": "var(--palette-color6)",\\
  "--text-caption_incomplete--borderBottomStyle": "none",\\
  "--text-caption_incomplete--textDecoration": "none",\\
  "--text-caption_incomplete--letterSpacing": "0",\\
  "--text-caption_incomplete--textTransform": "none",\\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\\
  "--text-caption_incomplete--textAlign": "center",\\
  "--text-caption_incomplete--justifyContent": "flex-start",\\
  "--text-caption_incomplete--marginTop": "auto",\\
  "--text-caption_incomplete--marginBottom": "0",\\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_hint--fontSize--desktop": "24px",\\
  "--text-caption_hint--fontSize--tablet": "24px",\\
  "--text-caption_hint--fontSize--mobile": "24px",\\
  "--text-caption_hint--fontFamily": "var(--font1)",\\
  "--text-caption_hint--fontWeight": "normal",\\
  "--text-caption_hint--fontType": "regular",\\
  "--text-caption_hint--fontStyle": "normal",\\
  "--text-caption_hint--fontStretch": "normal",\\
  "--text-caption_hint--lineHeight": "1.35",\\
  "--text-caption_hint--marginLeft": "0px",\\
  "--text-caption_hint--color": "var(--palette-color6)",\\
  "--text-caption_hint--borderBottomStyle": "none",\\
  "--text-caption_hint--textDecoration": "none",\\
  "--text-caption_hint--letterSpacing": "0",\\
  "--text-caption_hint--textTransform": "none",\\
  "--text-caption_hint--stroke": "var(--palette-color2)",\\
  "--text-caption_hint--textAlign": "center",\\
  "--text-caption_hint--justifyContent": "flex-start",\\
  "--text-caption_hint--marginTop": "auto",\\
  "--text-caption_hint--marginBottom": "0",\\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_retry--fontSize--desktop": "24px",\\
  "--text-caption_retry--fontSize--tablet": "24px",\\
  "--text-caption_retry--fontSize--mobile": "24px",\\
  "--text-caption_retry--fontFamily": "var(--font1)",\\
  "--text-caption_retry--fontWeight": "normal",\\
  "--text-caption_retry--fontType": "regular",\\
  "--text-caption_retry--fontStyle": "normal",\\
  "--text-caption_retry--fontStretch": "normal",\\
  "--text-caption_retry--lineHeight": "1.35",\\
  "--text-caption_retry--marginLeft": "0px",\\
  "--text-caption_retry--color": "var(--palette-color6)",\\
  "--text-caption_retry--borderBottomStyle": "none",\\
  "--text-caption_retry--textDecoration": "none",\\
  "--text-caption_retry--letterSpacing": "0",\\
  "--text-caption_retry--textTransform": "none",\\
  "--text-caption_retry--stroke": "var(--palette-color2)",\\
  "--text-caption_retry--textAlign": "center",\\
  "--text-caption_retry--justifyContent": "flex-start",\\
  "--text-caption_retry--marginTop": "auto",\\
  "--text-caption_retry--marginBottom": "0",\\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_timeout--fontSize--desktop": "24px",\\
  "--text-caption_timeout--fontSize--tablet": "24px",\\
  "--text-caption_timeout--fontSize--mobile": "24px",\\
  "--text-caption_timeout--fontFamily": "var(--font1)",\\
  "--text-caption_timeout--fontWeight": "normal",\\
  "--text-caption_timeout--fontType": "regular",\\
  "--text-caption_timeout--fontStyle": "normal",\\
  "--text-caption_timeout--fontStretch": "normal",\\
  "--text-caption_timeout--lineHeight": "1.35",\\
  "--text-caption_timeout--marginLeft": "0px",\\
  "--text-caption_timeout--color": "var(--palette-color6)",\\
  "--text-caption_timeout--borderBottomStyle": "none",\\
  "--text-caption_timeout--textDecoration": "none",\\
  "--text-caption_timeout--letterSpacing": "0",\\
  "--text-caption_timeout--textTransform": "none",\\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\\
  "--text-caption_timeout--textAlign": "center",\\
  "--text-caption_timeout--justifyContent": "flex-start",\\
  "--text-caption_timeout--marginTop": "auto",\\
  "--text-caption_timeout--marginBottom": "0",\\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_1--fontSize--desktop": "18px",\\
  "--text-caption_1--fontSize--tablet": "18px",\\
  "--text-caption_1--fontSize--mobile": "16px",\\
  "--text-caption_1--fontFamily": "var(--font2)",\\
  "--text-caption_1--fontWeight": "normal",\\
  "--text-caption_1--fontType": "regular",\\
  "--text-caption_1--fontStyle": "normal",\\
  "--text-caption_1--fontStretch": "normal",\\
  "--text-caption_1--lineHeight": "1.2",\\
  "--text-caption_1--marginLeft": "0px",\\
  "--text-caption_1--color": "#FFFFFF",\\
  "--text-caption_1--borderBottomStyle": "none",\\
  "--text-caption_1--textDecoration": "none",\\
  "--text-caption_1--letterSpacing": "0",\\
  "--text-caption_1--textTransform": "none",\\
  "--text-caption_1--stroke": "#00000000",\\
  "--text-caption_1--textAlign": "left",\\
  "--text-caption_1--justifyContent": "flex-start",\\
  "--text-caption_1--marginTop": "auto",\\
  "--text-caption_1--marginBottom": "0",\\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_2--fontSize--desktop": "20px",\\
  "--text-caption_2--fontSize--tablet": "20px",\\
  "--text-caption_2--fontSize--mobile": "18px",\\
  "--text-caption_2--fontFamily": "var(--font2)",\\
  "--text-caption_2--fontWeight": "normal",\\
  "--text-caption_2--fontType": "bold",\\
  "--text-caption_2--fontStyle": "normal",\\
  "--text-caption_2--fontStretch": "normal",\\
  "--text-caption_2--lineHeight": "1.2",\\
  "--text-caption_2--marginLeft": "0px",\\
  "--text-caption_2--color": "#FFFFFF",\\
  "--text-caption_2--borderBottomStyle": "none",\\
  "--text-caption_2--textDecoration": "none",\\
  "--text-caption_2--letterSpacing": "0",\\
  "--text-caption_2--textTransform": "none",\\
  "--text-caption_2--stroke": "#00000000",\\
  "--text-caption_2--textAlign": "left",\\
  "--text-caption_2--justifyContent": "flex-start",\\
  "--text-caption_2--marginTop": "auto",\\
  "--text-caption_2--marginBottom": "0",\\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_3--fontSize--desktop": "24px",\\
  "--text-caption_3--fontSize--tablet": "24px",\\
  "--text-caption_3--fontSize--mobile": "22px",\\
  "--text-caption_3--fontFamily": "var(--font1)",\\
  "--text-caption_3--fontWeight": "normal",\\
  "--text-caption_3--fontType": "italic",\\
  "--text-caption_3--fontStyle": "normal",\\
  "--text-caption_3--fontStretch": "normal",\\
  "--text-caption_3--lineHeight": "1.2",\\
  "--text-caption_3--marginLeft": "0px",\\
  "--text-caption_3--color": "#FFFFFF",\\
  "--text-caption_3--borderBottomStyle": "none",\\
  "--text-caption_3--textDecoration": "none",\\
  "--text-caption_3--letterSpacing": "0",\\
  "--text-caption_3--textTransform": "none",\\
  "--text-caption_3--stroke": "#00000000",\\
  "--text-caption_3--textAlign": "left",\\
  "--text-caption_3--justifyContent": "flex-start",\\
  "--text-caption_3--marginTop": "auto",\\
  "--text-caption_3--marginBottom": "0",\\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_4--fontSize--desktop": "22px",\\
  "--text-caption_4--fontSize--tablet": "22px",\\
  "--text-caption_4--fontSize--mobile": "20px",\\
  "--text-caption_4--fontFamily": "var(--font2)",\\
  "--text-caption_4--fontWeight": "normal",\\
  "--text-caption_4--fontType": "italic",\\
  "--text-caption_4--fontStyle": "normal",\\
  "--text-caption_4--fontStretch": "normal",\\
  "--text-caption_4--lineHeight": "1.3",\\
  "--text-caption_4--marginLeft": "0px",\\
  "--text-caption_4--color": "#666666",\\
  "--text-caption_4--borderBottomStyle": "none",\\
  "--text-caption_4--textDecoration": "none",\\
  "--text-caption_4--letterSpacing": "0",\\
  "--text-caption_4--textTransform": "none",\\
  "--text-caption_4--stroke": "#00000000",\\
  "--text-caption_4--textAlign": "left",\\
  "--text-caption_4--justifyContent": "flex-start",\\
  "--text-caption_4--marginTop": "auto",\\
  "--text-caption_4--marginBottom": "0",\\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-comment-box--fontSize--desktop": "20px",\\
  "--text-comment-box--fontSize--tablet": "20px",\\
  "--text-comment-box--fontSize--mobile": "20px",\\
  "--text-comment-box--fontFamily": "var(--font1)",\\
  "--text-comment-box--fontWeight": "normal",\\
  "--text-comment-box--fontType": "regular",\\
  "--text-comment-box--fontStyle": "normal",\\
  "--text-comment-box--fontStretch": "normal",\\
  "--text-comment-box--lineHeight": "1.35",\\
  "--text-comment-box--marginLeft": "0px",\\
  "--text-comment-box--color": "var(--palette-color6)",\\
  "--text-comment-box--borderBottomStyle": "none",\\
  "--text-comment-box--textDecoration": "none",\\
  "--text-comment-box--letterSpacing": "0",\\
  "--text-comment-box--textTransform": "none",\\
  "--text-comment-box--stroke": "var(--palette-color2)",\\
  "--text-comment-box--textAlign": "center",\\
  "--text-comment-box--justifyContent": "flex-start",\\
  "--text-comment-box--marginTop": "auto",\\
  "--text-comment-box--marginBottom": "0",\\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\\
\\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\\
\\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_greyscale--intensity": 100,\\
\\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_lighten--intensity": 80,\\
\\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_darken--intensity": 80,\\
\\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_overlay--intensity": 80,\\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\\
\\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_colorize--intensity": 80,\\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\\
\\
\\
  "--button-normal--primaryColor": "var(--palette-color7)",\\
  "--button-normal--borderColor": "var(--palette-color7)",\\
  "--button-normal--shadowColor": "var(--greyscale3)",\\
  "--text-button-normal--color": "var(--palette-color0)",\\
  "--text-button-normal--fontFamily": "var(--font2)",\\
  "--text-button-normal--fontType": "regular",\\
  "--text-button-normal--fontSize--desktop": "16px",\\
  "--text-button-normal--fontSize--tablet": "16px",\\
  "--text-button-normal--fontSize--mobile": "16px",\\
\\
  "--button-selected--primaryColor": "var(--palette-color5)",\\
  "--button-selected--borderColor": "var(--palette-color5)",\\
  "--button-selected--shadowColor": "var(--greyscale3)",\\
  "--text-button-selected--color": "var(--palette-color0)",\\
  "--text-button-selected--fontFamily": "var(--font2)",\\
  "--text-button-selected--fontType": "regular",\\
  "--text-button-selected--fontSize--desktop": "16px",\\
  "--text-button-selected--fontSize--tablet": "16px",\\
  "--text-button-selected--fontSize--mobile": "16px",\\
\\
  "--button-disabled--primaryColor": "var(--palette-color3)",\\
  "--button-disabled--borderColor": "var(--palette-color3)",\\
  "--button-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-button-disabled--color": "var(--palette-color4)",\\
  "--text-button-disabled--fontFamily": "var(--font2)",\\
  "--text-button-disabled--fontType": "regular",\\
  "--text-button-disabled--fontSize--desktop": "16px",\\
  "--text-button-disabled--fontSize--tablet": "16px",\\
  "--text-button-disabled--fontSize--mobile": "16px",\\
\\
  "--button-hover--primaryColor": "#112FA7",\\
  "--button-hover--borderColor": "#112FA7",\\
  "--button-hover--shadowColor": "var(--greyscale3)",\\
  "--text-button-hover--color": "var(--palette-color0)",\\
  "--text-button-hover--fontFamily": "var(--font2)",\\
  "--text-button-hover--fontType": "regular",\\
  "--text-button-hover--fontSize--desktop": "16px",\\
  "--text-button-hover--fontSize--tablet": "16px",\\
  "--text-button-hover--fontSize--mobile": "16px",\\
\\
  "--button-visited--primaryColor": "#112FA780",\\
  "--button-visited--borderColor": "#112FA780",\\
  "--button-visited--shadowColor": "var(--greyscale3)",\\
  "--text-button-visited--color": "var(--palette-color0)",\\
  "--text-button-visited--fontFamily": "var(--font2)",\\
  "--text-button-visited--fontType": "regular",\\
  "--text-button-visited--fontSize--desktop": "16px",\\
  "--text-button-visited--fontSize--tablet": "16px",\\
  "--text-button-visited--fontSize--mobile": "16px",\\
\\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-normal--color": "var(--palette-color4)",\\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\\
  "--text-checkbox-normal--fontType": "regular",\\
  "--text-checkbox-normal--fontSize--desktop": "22px",\\
  "--text-checkbox-normal--fontSize--tablet": "20px",\\
  "--text-checkbox-normal--fontSize--mobile": "20px",\\
\\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-selected--color": "var(--palette-color4)",\\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\\
  "--text-checkbox-selected--fontType": "regular",\\
  "--text-checkbox-selected--fontSize--desktop": "22px",\\
  "--text-checkbox-selected--fontSize--tablet": "20px",\\
  "--text-checkbox-selected--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-checked--fontType": "regular",\\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-hover--color": "var(--palette-color5)",\\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\\
  "--text-checkbox-hover--fontType": "regular",\\
  "--text-checkbox-hover--fontSize--desktop": "22px",\\
  "--text-checkbox-hover--fontSize--tablet": "20px",\\
  "--text-checkbox-hover--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \\
  "--inputfield-normal--borderColor": "var(--palette-color3)",\\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-normal--color": "var(--palette-color4)",\\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\\
  "--text-inputfield-normal--fontType": "regular",\\
  "--text-inputfield-normal--fontSize--desktop": "18px",\\
  "--text-inputfield-normal--fontSize--tablet": "20px",\\
  "--text-inputfield-normal--fontSize--mobile": "20px",\\
\\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\\
  "--inputfield-active--borderColor": "var(--palette-color7)",\\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\\
  "--text-inputfield-active--color": "var(--palette-color4)",\\
  "--text-inputfield-active--fontFamily": "var(--font1)",\\
  "--text-inputfield-active--fontType": "regular",\\
  "--text-inputfield-active--fontSize--desktop": "18px",\\
  "--text-inputfield-active--fontSize--tablet": "20px",\\
  "--text-inputfield-active--fontSize--mobile": "20px",\\
\\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\\
  "--text-inputfield-disabled--fontType": "regular",\\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\\
\\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\\
  "--text-inputfield-focusLost--fontType": "regular",\\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\\
\\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\\
  "--inputfield-error--borderColor": "var(--error)",\\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-error--color": "var(--palette-color4)",\\
  "--text-inputfield-error--fontFamily": "var(--font1)",\\
  "--text-inputfield-error--fontType": "regular",\\
  "--text-inputfield-error--fontSize--desktop": "18px",\\
  "--text-inputfield-error--fontSize--tablet": "20px",\\
  "--text-inputfield-error--fontSize--mobile": "20px",\\
\\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-normal--color": "var(--palette-color4)",\\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\\
  "--text-dropdown-normal--fontType": "italic",\\
  "--text-dropdown-normal--fontSize--desktop": "18px",\\
  "--text-dropdown-normal--fontSize--tablet": "18px",\\
  "--text-dropdown-normal--fontSize--mobile": "18px",\\
\\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-selected--color": "var(--palette-color4)",\\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\\
  "--text-dropdown-selected--fontType": "italic",\\
  "--text-dropdown-selected--fontSize--desktop": "18px",\\
  "--text-dropdown-selected--fontSize--tablet": "18px",\\
  "--text-dropdown-selected--fontSize--mobile": "18px",\\
\\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\\
  "--text-dropdown-disabled--fontType": "italic",\\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\\
\\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-hover--color": "var(--palette-color4)",\\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\\
  "--text-dropdown-hover--fontType": "italic",\\
  "--text-dropdown-hover--fontSize--desktop": "18px",\\
  "--text-dropdown-hover--fontSize--tablet": "18px",\\
  "--text-dropdown-hover--fontSize--mobile": "18px",\\
\\
  "--radio-normal--primaryColor": "var(--palette-color0)",\\
  "--radio-normal--borderColor": "var(--palette-color3)",\\
  "--radio-normal--shadowColor": "var(--greyscale3)",\\
  "--text-radio-normal--color": "var(--palette-color4)",\\
  "--text-radio-normal--fontFamily": "var(--font1)",\\
  "--text-radio-normal--fontType": "regular",\\
  "--text-radio-normal--fontSize--desktop": "22px",\\
  "--text-radio-normal--fontSize--tablet": "20px",\\
  "--text-radio-normal--fontSize--mobile": "20px",\\
\\
  "--radio-selected--primaryColor": "var(--palette-color0)",\\
  "--radio-selected--borderColor": "var(--palette-color4)",\\
  "--radio-selected--shadowColor": "var(--greyscale3)",\\
  "--text-radio-selected--color": "var(--palette-color4)",\\
  "--text-radio-selected--fontFamily": "var(--font1)",\\
  "--text-radio-selected--fontType": "regular",\\
  "--text-radio-selected--fontSize--desktop": "22px",\\
  "--text-radio-selected--fontSize--tablet": "20px",\\
  "--text-radio-selected--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-checked--fontType": "regular",\\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--radio-hover--primaryColor": "var(--palette-color0)",\\
  "--radio-hover--borderColor": "var(--palette-color3)",\\
  "--radio-hover--shadowColor": "var(--greyscale3)",\\
  "--text-radio-hover--color": "var(--palette-color5)",\\
  "--text-radio-hover--fontFamily": "var(--font1)",\\
  "--text-radio-hover--fontType": "regular",\\
  "--text-radio-hover--fontSize--desktop": "22px",\\
  "--text-radio-hover--fontSize--tablet": "20px",\\
  "--text-radio-hover--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-unchecked--fontType": "regular",\\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--video_preset-color": "#666666",\\
  "--video_preset-borderColor": "#666666",\\
  \\
  "--clickbox-preset-fill-color": "#3F80E4",\\
\\
  "--drag-object-default-state-fill-color": "255, 255, 255",\\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drag-object-default-state-border-color": "214, 213, 209",\\
  "--drag-object-hover-state-border-color": "214, 213, 209",\\
  "--drag-object-transition-state-border-color": "214, 213, 209",\\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\\
\\
  "--drop-object-default-state-fill-color": "255, 255, 255",\\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drop-object-default-state-border-color": "42, 49, 62",\\
  "--drop-object-hover-state-border-color": "230, 132, 80",\\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\\
}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
slideAudios:'StAd5',
vestr:0,
vim:0,
slides:'Slide390,Slide507,Slide544,Slide661,Slide698,Slide735,Slide779,Slide813,Slide927,Slide964,Slide1081,Slide1118,Slide1155,Slide1272,Slide1389,Slide1506,Slide1623,Slide1740,Slide1857,Slide1974,Slide2091,Slide2128,Slide2242,Slide2359,Slide2510,Slide2627,Slide2744,Slide2861,Slide2973',
slideVideos:['si772'],
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Simulation slide 1","type":"slide","parentId":null,"id":"Slide390","isVisible":true,"slideVisited":false,"originalId":390,"labelShouldBeInSync":true},{"label":"Simulation slide 2","type":"slide","parentId":null,"id":"Slide507","isVisible":true,"slideVisited":false,"originalId":507,"labelShouldBeInSync":true},{"label":"Simulation slide 3","type":"slide","parentId":null,"id":"Slide544","isVisible":true,"slideVisited":false,"originalId":544,"labelShouldBeInSync":true},{"label":"Simulation slide 4","type":"slide","parentId":null,"id":"Slide661","isVisible":true,"slideVisited":false,"originalId":661,"labelShouldBeInSync":true},{"label":"Simulation slide 5","type":"slide","parentId":null,"id":"Slide698","isVisible":true,"slideVisited":false,"originalId":698,"labelShouldBeInSync":true},{"label":"Simulation slide 6","type":"slide","parentId":null,"id":"Slide735","isVisible":true,"slideVisited":false,"originalId":735,"labelShouldBeInSync":true},{"label":"Simulation slide 7","type":"slide","parentId":null,"id":"Slide779","isVisible":true,"slideVisited":false,"originalId":779,"labelShouldBeInSync":true},{"label":"Simulation slide 8","type":"slide","parentId":null,"id":"Slide813","isVisible":true,"slideVisited":false,"originalId":813,"labelShouldBeInSync":true},{"label":"Simulation slide 9","type":"slide","parentId":null,"id":"Slide927","isVisible":true,"slideVisited":false,"originalId":927,"labelShouldBeInSync":true},{"label":"Simulation slide 10","type":"slide","parentId":null,"id":"Slide964","isVisible":true,"slideVisited":false,"originalId":964,"labelShouldBeInSync":true},{"label":"Simulation slide 11","type":"slide","parentId":null,"id":"Slide1081","isVisible":true,"slideVisited":false,"originalId":1081,"labelShouldBeInSync":true},{"label":"Simulation slide 12","type":"slide","parentId":null,"id":"Slide1118","isVisible":true,"slideVisited":false,"originalId":1118,"labelShouldBeInSync":true},{"label":"Simulation slide 13","type":"slide","parentId":null,"id":"Slide1155","isVisible":true,"slideVisited":false,"originalId":1155,"labelShouldBeInSync":true},{"label":"Simulation slide 14","type":"slide","parentId":null,"id":"Slide1272","isVisible":true,"slideVisited":false,"originalId":1272,"labelShouldBeInSync":true},{"label":"Simulation slide 15","type":"slide","parentId":null,"id":"Slide1389","isVisible":true,"slideVisited":false,"originalId":1389,"labelShouldBeInSync":true},{"label":"Simulation slide 16","type":"slide","parentId":null,"id":"Slide1506","isVisible":true,"slideVisited":false,"originalId":1506,"labelShouldBeInSync":true},{"label":"Simulation slide 17","type":"slide","parentId":null,"id":"Slide1623","isVisible":true,"slideVisited":false,"originalId":1623,"labelShouldBeInSync":true},{"label":"Simulation slide 18","type":"slide","parentId":null,"id":"Slide1740","isVisible":true,"slideVisited":false,"originalId":1740,"labelShouldBeInSync":true},{"label":"Simulation slide 19","type":"slide","parentId":null,"id":"Slide1857","isVisible":true,"slideVisited":false,"originalId":1857,"labelShouldBeInSync":true},{"label":"Simulation slide 20","type":"slide","parentId":null,"id":"Slide1974","isVisible":true,"slideVisited":false,"originalId":1974,"labelShouldBeInSync":true},{"label":"Simulation slide 21","type":"slide","parentId":null,"id":"Slide2091","isVisible":true,"slideVisited":false,"originalId":2091,"labelShouldBeInSync":true},{"label":"Simulation slide 22","type":"slide","parentId":null,"id":"Slide2128","isVisible":true,"slideVisited":false,"originalId":2128,"labelShouldBeInSync":true},{"label":"Simulation slide 23","type":"slide","parentId":null,"id":"Slide2242","isVisible":true,"slideVisited":false,"originalId":2242,"labelShouldBeInSync":true},{"label":"Simulation slide 24","type":"slide","parentId":null,"id":"Slide2359","isVisible":true,"slideVisited":false,"originalId":2359,"labelShouldBeInSync":true},{"label":"Simulation slide 26","type":"slide","parentId":null,"id":"Slide2510","isVisible":true,"slideVisited":false,"originalId":2510,"labelShouldBeInSync":true},{"label":"Simulation slide 27","type":"slide","parentId":null,"id":"Slide2627","isVisible":true,"slideVisited":false,"originalId":2627,"labelShouldBeInSync":true},{"label":"Simulation slide 28","type":"slide","parentId":null,"id":"Slide2744","isVisible":true,"slideVisited":false,"originalId":2744,"labelShouldBeInSync":true},{"label":"Simulation slide 29","type":"slide","parentId":null,"id":"Slide2861","isVisible":true,"slideVisited":false,"originalId":2861,"labelShouldBeInSync":true},{"label":"Simulation slide 30","type":"slide","parentId":null,"id":"Slide2973","isVisible":true,"slideVisited":false,"originalId":2973,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:390,
text:['""']
}
,{
link:507,
text:['""']
}
,{
link:544,
text:['""']
}
,{
link:661,
text:['""']
}
,{
link:698,
text:['""']
}
,{
link:735,
text:['""']
}
,{
link:779,
text:['""']
}
,{
link:813,
text:['""']
}
,{
link:927,
text:['""']
}
,{
link:964,
text:['""']
}
,{
link:1081,
text:['""']
}
,{
link:1118,
text:['""']
}
,{
link:1155,
text:['""']
}
,{
link:1272,
text:['""']
}
,{
link:1389,
text:['""']
}
,{
link:1506,
text:['""']
}
,{
link:1623,
text:['""']
}
,{
link:1740,
text:['""']
}
,{
link:1857,
text:['""']
}
,{
link:1974,
text:['""']
}
,{
link:2091,
text:['""']
}
,{
link:2128,
text:['""']
}
,{
link:2242,
text:['""']
}
,{
link:2359,
text:['""']
}
,{
link:2510,
text:['""']
}
,{
link:2627,
text:['""']
}
,{
link:2744,
text:['""']
}
,{
link:2861,
text:['""']
}
,{
link:2973,
text:['""']
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01115.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01152.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01189.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01306.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01423.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01540.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01657.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01774.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01891.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02008.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02125.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02276.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02544.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02661.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02778.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03007.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0424.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0541.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0578.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0695.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0732.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0768.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0961.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0998.bmp',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
'vr/Vi761.mp4'
];
cp.model.tocVideos=[
];
cp.model.audios=[
'ar/StAd4.mp3'
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',29,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxNum_1','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxNum_1,variableEditBoxStr_1,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
